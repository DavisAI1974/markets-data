# Instance 489 individual market record

Family `ow-558bf5e89cbc2e638d71` · instrument `150611` · first observed **2023-10-18T14:12:16.464095220+00:00**.

[Previous instance](0488.md)
[Next instance](0490.md)

## Strict pre-event observations

Decision cutoff `1697638336464095219` receive nanoseconds; cursor cap `418693`. Eligible completed-group source `319574` was known by `1697638336462960063`, cursor `418682`. The family group itself is excluded.

| Measurement | Recorded value |
|---|---:|
| Best bid | 3.094000 |
| Best ask | 3.095000 |
| Midquote | 3.094500 |
| Spread | 0.001000 |
| Full bid size | 1733.000000 |
| Full ask size | 1265.000000 |
| Producer depth_n imbalance | 0.051988 |
| Full-book imbalance | 0.156104 |

| Pre-event rolling window | Buy-aggressor quantity | Sell-aggressor quantity |
|---:|---:|---:|
| 1 s | 20.000000 | 72.000000 |
| 5 s | 21.000000 | 78.000000 |
| 20 s | 43.000000 | 79.000000 |
| 60 s | 82.000000 | 287.000000 |
| 300 s | 253.000000 | 441.000000 |

These windows overlap. Values are the recorded quantities at the decision boundary; they do not identify the exact instant each pressure condition first became observable. Raw missingness/reasons and other contemporaneous measurements remain in the linked per-instance JSON and measurement ledger.

## Frozen forecasts and subsequently observed outcomes

### Signed endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | 0.000000 | 0.000000 | 0.002000 | 0.003000 | 0.004500 | 0.005500 | 0.010000 | 0.008000 | 0.019500 |
| Linear ridge | 0.000468 | -0.000253 | 0.000106 | 0.003294 | 0.000583 | 0.008318 | 0.015935 | 0.004306 | 0.004394 |
| Shallow trees | 0.001238 | 0.000787 | 0.001020 | 0.000447 | 0.000033 | 0.001364 | 0.005428 | -0.003495 | -0.003507 |
| Deeper trees | 0.000721 | 0.001101 | 0.001052 | 0.000615 | -0.000506 | 0.002384 | 0.008284 | -0.002806 | -0.002564 |
| Median-loss trees | 0.000937 | 0.000797 | 0.001544 | 0.000398 | 0.000442 | 0.000931 | 0.001058 | -0.003867 | -0.001904 |
| NeuralTree | -0.000073 | -0.000106 | 0.000033 | -0.000106 | 0.000316 | 0.000295 | 0.000361 | -0.000325 | 0.000844 |
| Residual MLP | 0.001067 | 0.002744 | -0.000499 | 0.000381 | -0.000068 | 0.008383 | 0.009412 | -0.005290 | 0.005971 |
| TabM | -0.000088 | 0.000642 | 0.001772 | 0.000450 | 0.003677 | 0.007671 | 0.000450 | 0.009478 | -0.019727 |
| Lower quantile | -0.000953 | -0.000676 | -0.000747 | -0.002116 | -0.000903 | -0.001797 | -0.001573 | -0.006273 | -0.005600 |
| Upper quantile | 0.001834 | 0.001814 | 0.001982 | 0.000942 | 0.001759 | 0.004915 | 0.007284 | 0.002715 | 0.006854 |

### Absolute endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | 0.000000 | 0.000000 | 0.002000 | 0.003000 | 0.004500 | 0.005500 | 0.010000 | 0.008000 | 0.019500 |
| Linear ridge | -0.000493 | -0.000492 | -0.001118 | 0.000659 | 0.002351 | 0.009335 | 0.015512 | 0.000293 | 0.008451 |
| Shallow trees | 0.002474 | 0.002673 | 0.002666 | 0.001694 | 0.001564 | 0.004987 | 0.009776 | 0.011049 | 0.007988 |
| Deeper trees | 0.002508 | 0.003023 | 0.003334 | 0.001602 | 0.001431 | 0.005532 | 0.012636 | 0.012408 | 0.008441 |
| Median-loss trees | 0.001703 | 0.001461 | 0.001908 | 0.002073 | 0.001903 | 0.006087 | 0.005170 | 0.007030 | 0.006503 |
| NeuralTree | 0.000656 | 0.000831 | 0.001116 | 0.001539 | 0.001759 | 0.002876 | 0.004147 | 0.006369 | 0.008029 |
| Residual MLP | 0.002424 | 0.001967 | 0.002010 | 0.003418 | 0.004393 | 0.010438 | 0.012681 | 0.001117 | 0.016130 |
| TabM | 0.001071 | -0.001847 | 0.001606 | 0.002556 | -0.009425 | 0.008032 | 0.003066 | 0.014460 | 0.013167 |
| Lower quantile | 0.000119 | 0.000201 | 0.000432 | 0.000768 | 0.000476 | 0.002374 | 0.002677 | 0.001404 | 0.003469 |
| Upper quantile | 0.001973 | 0.001631 | 0.002951 | 0.003013 | 0.003590 | 0.008283 | 0.010111 | 0.012321 | 0.010932 |

### Occurrence of any first-observed family for the instrument

| Perspective | 120 s | 300 s | 600 s |
|---|---:|---:|---:|
| **Observed later** | 1.000000 | 1.000000 | 1.000000 |
| Linear ridge | 0.000001 | 0.999999 | 0.951252 |
| Shallow trees | 0.791957 | 0.861483 | 0.959648 |
| Deeper trees | 0.847997 | 0.887576 | 0.963380 |
| NeuralTree | 0.582860 | 0.570999 | 0.574482 |
| Residual MLP | 0.995496 | 0.964308 | 0.854310 |
| TabM | 0.999919 | 0.998723 | 0.999736 |

Recorded held-out fold(s): 3. Original training chronology, family purge and embargo remain unchanged. Observed endpoints are hindsight labels, not predictors. A missing horizon remains unavailable. Quantile forecasts describe separate tails rather than competing point estimates. Negative magnitude forecasts are preserved as invalid outputs, without clipping.

## Source and interpretation boundaries

[Chronological index](../chronological-instance-index.csv) · [All pre-event forecasts and removal refits](../all-pre-event-forecasts.csv.gz) · [Individual JSON records](../individual-instance-records.jsonl.gz) · [Pre-event measurements](../pre-event-measurements.csv.gz) · [Clock receipts](../pre-event-clock-receipts.csv)

This is a first-observed structural family event, not a demonstrated original order birth, causal intervention or filled trade. Averages can provide context; an entry condition requires instance-specific timing, confirmation and invalidation evidence. Semantic coverage remains NOT_PASSED and neural repeatability/domain caveats remain unresolved.

No dedicated complete consecutive book replay has been generated for this instance. Some nearby events overlap the saved window centered on instance 375; the card itself contains context observations and horizon endpoints, not an invented continuous path.
