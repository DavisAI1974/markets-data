# Instance 195 individual market record

Family `ow-e76d99f9199540683dfd` · instrument `150611` · first observed **2023-10-18T10:57:19.581492038+00:00**.

[Previous instance](0194.md)
[Next instance](0196.md)

## Strict pre-event observations

Decision cutoff `1697626639581492037` receive nanoseconds; cursor cap `147304`. Eligible completed-group source `117597` was known by `1697626639580841792`, cursor `147295`. The family group itself is excluded.

| Measurement | Recorded value |
|---|---:|
| Best bid | 3.092000 |
| Best ask | 3.093000 |
| Midquote | 3.092500 |
| Spread | 0.001000 |
| Full bid size | 1763.000000 |
| Full ask size | 944.000000 |
| Producer depth_n imbalance | 0.004926 |
| Full-book imbalance | 0.302549 |

| Pre-event rolling window | Buy-aggressor quantity | Sell-aggressor quantity |
|---:|---:|---:|
| 1 s | 4.000000 | 0.000000 |
| 5 s | 4.000000 | 0.000000 |
| 20 s | 5.000000 | 0.000000 |
| 60 s | 16.000000 | 1.000000 |
| 300 s | 104.000000 | 77.000000 |

These windows overlap. Values are the recorded quantities at the decision boundary; they do not identify the exact instant each pressure condition first became observable. Raw missingness/reasons and other contemporaneous measurements remain in the linked per-instance JSON and measurement ledger.

## Frozen forecasts and subsequently observed outcomes

### Signed endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | 0.003000 | 0.003000 | 0.001000 | -0.004500 | -0.004500 | -0.002500 | 0.004000 | 0.002500 | 0.012500 |
| Linear ridge | 0.000747 | 0.000281 | 0.000111 | 0.001860 | -0.001203 | 0.004953 | 0.009680 | 0.002542 | -0.000087 |
| Shallow trees | 0.000451 | 0.000580 | 0.000496 | 0.001397 | -0.000373 | 0.002440 | 0.001650 | -0.004851 | -0.003024 |
| Deeper trees | 0.000793 | -0.000021 | 0.000757 | 0.001307 | -0.001023 | 0.003445 | 0.001660 | -0.004104 | -0.001750 |
| Median-loss trees | 0.001257 | 0.001134 | 0.001173 | -0.000168 | -0.000543 | 0.000535 | 0.000189 | -0.002934 | -0.007305 |
| NeuralTree | -0.000073 | -0.000106 | 0.000033 | -0.000106 | 0.000316 | 0.000295 | 0.000361 | -0.000325 | 0.000844 |
| Residual MLP | 0.000725 | 0.001386 | 0.000626 | 0.001071 | 0.001200 | 0.005075 | 0.007990 | -0.002657 | -0.004467 |
| TabM | -0.000080 | -0.000463 | -0.000842 | -0.003224 | 0.001127 | 0.010417 | 0.012754 | 0.006224 | -0.015285 |
| Lower quantile | -0.000756 | -0.000778 | -0.001000 | -0.000568 | -0.001882 | -0.001703 | -0.003160 | -0.005348 | -0.006563 |
| Upper quantile | 0.001809 | 0.001642 | 0.002244 | 0.001344 | 0.001890 | 0.004223 | 0.007608 | 0.003063 | 0.005325 |

### Absolute endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | 0.003000 | 0.003000 | 0.001000 | 0.004500 | 0.004500 | 0.002500 | 0.004000 | 0.002500 | 0.012500 |
| Linear ridge | 0.002460 | 0.002167 | 0.002015 | 0.002221 | 0.001695 | 0.006963 | 0.011461 | 0.010429 | 0.015301 |
| Shallow trees | 0.001897 | 0.001895 | 0.002111 | 0.001843 | 0.002174 | 0.006778 | 0.009300 | 0.009702 | 0.006589 |
| Deeper trees | 0.002056 | 0.002399 | 0.002434 | 0.001816 | 0.002132 | 0.008083 | 0.012009 | 0.011903 | 0.007264 |
| Median-loss trees | 0.001399 | 0.001185 | 0.002192 | 0.001936 | 0.002299 | 0.005883 | 0.007390 | 0.005596 | 0.005503 |
| NeuralTree | 0.000656 | 0.000831 | 0.001116 | 0.001539 | 0.001759 | 0.002876 | 0.004147 | 0.006369 | 0.008029 |
| Residual MLP | 0.002924 | 0.002164 | 0.002100 | 0.002683 | 0.002764 | 0.008574 | 0.013695 | 0.006079 | 0.011120 |
| TabM | 0.001378 | 0.001699 | 0.001554 | 0.002089 | -0.000630 | -0.000690 | 0.005958 | 0.013797 | 0.002543 |
| Lower quantile | 0.000620 | 0.000283 | 0.000583 | 0.000583 | 0.001261 | 0.000540 | 0.001738 | 0.001783 | 0.002832 |
| Upper quantile | 0.001965 | 0.002610 | 0.002975 | 0.002961 | 0.002978 | 0.006780 | 0.009517 | 0.010174 | 0.008211 |

### Occurrence of any first-observed family for the instrument

| Perspective | 120 s | 300 s | 600 s |
|---|---:|---:|---:|
| **Observed later** | 1.000000 | 1.000000 | 1.000000 |
| Linear ridge | 0.999999 | 0.999999 | 0.999999 |
| Shallow trees | 0.813147 | 0.817853 | 0.959648 |
| Deeper trees | 0.855153 | 0.882095 | 0.963811 |
| NeuralTree | 0.582844 | 0.571097 | 0.574216 |
| Residual MLP | 0.980196 | 0.941882 | 0.930232 |
| TabM | 0.998967 | 0.998260 | 0.999695 |

Recorded held-out fold(s): 3. Original training chronology, family purge and embargo remain unchanged. Observed endpoints are hindsight labels, not predictors. A missing horizon remains unavailable. Quantile forecasts describe separate tails rather than competing point estimates. Negative magnitude forecasts are preserved as invalid outputs, without clipping.

## Source and interpretation boundaries

[Chronological index](../chronological-instance-index.csv) · [All pre-event forecasts and removal refits](../all-pre-event-forecasts.csv.gz) · [Individual JSON records](../individual-instance-records.jsonl.gz) · [Pre-event measurements](../pre-event-measurements.csv.gz) · [Clock receipts](../pre-event-clock-receipts.csv)

This is a first-observed structural family event, not a demonstrated original order birth, causal intervention or filled trade. Averages can provide context; an entry condition requires instance-specific timing, confirmation and invalidation evidence. Semantic coverage remains NOT_PASSED and neural repeatability/domain caveats remain unresolved.

No dedicated complete consecutive book replay has been generated for this instance. Some nearby events overlap the saved window centered on instance 375; the card itself contains context observations and horizon endpoints, not an invented continuous path.
