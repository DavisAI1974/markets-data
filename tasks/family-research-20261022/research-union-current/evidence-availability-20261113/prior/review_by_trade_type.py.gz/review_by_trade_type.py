"""Read-only case review; keeps days, source fields and tick observations separate."""
import collections
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(r'E:\Markets\outputs\dipole-experiment-20261110')
OUT = Path(__file__).parent
DAYS = ['20231002', '20231003', '20231017', '20231018']


def rank_corr(x, y):
    valid = np.isfinite(x) & np.isfinite(y)
    a, b = np.asarray(x)[valid], np.asarray(y)[valid]
    result = {'pairs': int(valid.sum()), 'rho': None}
    if len(a) >= 8 and len(set(a)) > 1 and len(set(b)) > 1:
        result['rho'] = float(np.corrcoef(pd.Series(a).rank(), pd.Series(b).rank())[0, 1])
    return result


def numeric(v, path=''):
    if isinstance(v, str):
        try:
            v = json.loads(v)
        except (ValueError, TypeError):
            return
    if isinstance(v, dict):
        # Missing-state placeholders are not measured zeroes.
        if 'state_code' in v:
            if v.get('state') == 'PRESENT' and v['state_code'] == 0:
                yield path + '.raw_float64', float(v['raw_float64'])
            return
        for k, z in v.items():
            if k in {'state', 'status', 'reason', 'scope'}:
                continue
            if any(s in k for s in ['_ns', 'cursor', 'ordinal', 'sequence', 'order_id', 'instrument_id', 'source_', 'stretch_id', 'leg_ids', 'segment', 'group_ordinal']):
                continue
            yield from numeric(z, path + '.' + k if path else k)
    elif isinstance(v, list) and path.endswith('top10_json'):
        for i, row in enumerate(v):
            for j, label in enumerate(['price_raw', 'size', 'orders']):
                yield f'{path}.level{i+1}.{label}', float(row[j])
    elif isinstance(v, (int, float)) and not isinstance(v, bool) and np.isfinite(v):
        yield path, float(v)


pkg = json.loads((ROOT / 'package.json').read_text(encoding='utf8'))
prior_results = json.loads((OUT / 'case_results.json').read_text())
review = []
for category in range(8):
    for day in DAYS:
        file = ROOT / f'{day}-{category}.json'
        raw = file.read_bytes()
        d = json.loads(raw)
        rows, headers = d['rows'], d['headers']
        indexes = {h: i for i, h in enumerate(headers)}
        assert all(f in indexes for f in pkg['all_layer_fields'])
        assert len(headers) == 167
        times = np.array([int(r[1]) for r in rows], dtype=np.int64)
        known = np.array([int(r[3]) for r in rows], dtype=np.int64)
        prices = np.array([r[8] for r in rows], dtype=float)
        assert np.all(np.diff(times) >= 0)
        leg = [i for i, r in enumerate(rows) if r[6]]
        a, b = leg[0], leg[-1]
        assert leg == list(range(a, b + 1))
        phase = np.array([r[5] == 'Dipole lifecycle' for r in rows])
        # The target starts from the last recorded trade known at availability,
        # excluding intervening prints inside the same emission group.
        baseline = np.searchsorted(times, known, side='right') - 1
        targets = {}
        for horizon in [1, 5]:
            future = np.searchsorted(times, known + horizon * 1_000_000_000)
            y = np.full(len(rows), np.nan)
            for i, j in enumerate(future):
                k = baseline[i]
                if (phase[i] and 0 <= k < len(rows) and j < len(rows)
                        and phase[k] and phase[j] and j > k
                        and times[j] <= known[i] + (horizon + 2) * 1_000_000_000):
                    y[i] = prices[j] - prices[k]
            targets[horizon] = y
        field_audit = {}
        signals = collections.defaultdict(lambda: np.full(len(rows), np.nan))
        state_counts = collections.defaultdict(collections.Counter)
        availability_errors = []
        for field in pkg['all_layer_fields']:
            col = indexes[field]
            vals = [r[col] for r in rows]
            audit = {'distinct_original_values': len({json.dumps(v, sort_keys=True) for v in vals})}
            if ' | ' in field:
                parsed = [json.loads(v) for v in vals]
                audit['statuses'] = dict(collections.Counter(v.get('status') for v in parsed))
                for i, v in enumerate(parsed):
                    value = v.get('values')
                    if field.startswith('S') and isinstance(value, dict):
                        for clock, record in value.items():
                            state_counts[clock][record.get('state')] += 1
                    for key, number in numeric(value):
                        # Keep each member separate. Cross-day timing screen uses
                        # before-book operands; other fields remain in the audit.
                        if field.startswith(('L039', 'L040', 'L045', 'L047', 'L049')) and key.startswith('before.'):
                            signals[field + ' :: ' + key][i] = number
            field_audit[field] = audit
        for i, r in enumerate(rows):
            provenance = json.loads(r[indexes['L029 | raw_source_identity_provenance_clocks_integrity']])['values']
            if int(provenance['before']['known_by_ns']) > int(r[1]):
                availability_errors.append(i)
            for name, col in [('Native dipole ratio', 12), ('Native roll buy', 16), ('Native roll sell', 17), ('Trade size', 9)]:
                if r[col] is not None:
                    signals[name][i] = r[col]
            if r[12] is not None and r[15] is not None and int(r[15]) > int(r[1]):
                availability_errors.append(i)
        before10 = [i for i in range(a) if known[i] < times[a] - 10_000_000_000]
        points = {'previous_trade': a - 1, 'leg_start': a, 'leg_end': b}
        if before10:
            points['last_available_at_least_10s_before'] = before10[-1]
        evidence = {}
        for label, i in points.items():
            r = rows[i]
            evidence[label] = {headers[j]: r[j] for j in [0, 1, 3, 8, 9, 10, 12, 15, 19, 20, 23, 24]}
            evidence[label]['zero_based_row'] = i
            evidence[label]['best_quotes'] = json.loads(r[indexes['L045 | spread_and_depth_imbalance']])['values']
        recognition = d['life']['recognition_ns']
        result = {
            'day': day, 'category_index': category, 'category': d['category'],
            'source_sha256': hashlib.sha256(raw).hexdigest(), 'ticks': len(rows),
            'lifecycle_ticks': int(phase.sum()), 'leg_ticks': len(leg),
            'leg_start_ET': d['leg_start_ET'], 'leg_end_ET': d['leg_end_ET'],
            'duration_s': d['duration_s'], 'price_change_ticks': d['price_change_ticks'],
            'recognition_vs_start_s': (recognition - times[a]).item() / 1e9,
            'recognition_vs_end_s': (recognition - times[b]).item() / 1e9,
            'ends_at_previous_trade_price': bool(prices[b] == prices[a - 1]),
            'availability_errors': availability_errors,
            'evidence': evidence, 'all_141_fields_audit': field_audit,
            's_state_counts': {k: dict(v) for k, v in state_counts.items()},
            'forward_checks': {key: {str(h): rank_corr(x, y) for h, y in targets.items()} for key, x in signals.items()},
            'prior_lifecycle_checks': [v for v in prior_results if v['day'] == day and v['case'] == category],
        }
        review.append(result)
    print('Reviewed type', category + 1, flush=True)
assert len(review) == 32 and sum(x['ticks'] for x in review) == 5513
assert all(len(x['all_141_fields_audit']) == 141 for x in review)
assert all(not x['availability_errors'] for x in review)
(OUT / 'trade_type_review.json').write_text(json.dumps({
    'method': '32 selected examples, separate per-day results; all original fields audited; all rows retained in source. Forward rank correlations use field levels against price change from latest trade at record availability to first trade at availability+horizon (maximum 2s excess). Lifecycle only. Eight pairs required; no significance or independent-validation claim. Before operands and native availability clocks checked. State-code placeholders excluded from numeric extraction. No cross-day averaging.',
    'cases': review,
}, indent=2, allow_nan=False), encoding='utf8')
print('Wrote trade_type_review.json; all assertions passed')
