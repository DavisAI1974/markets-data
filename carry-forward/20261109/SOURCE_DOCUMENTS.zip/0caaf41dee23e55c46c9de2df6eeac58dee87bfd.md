# Instance 397 individual market record

Family `ow-a58d788d6a9f604e928f` · instrument `150611` · first observed **2023-10-18T13:17:44.801581430+00:00**.

[Previous instance](0396.md)
[Next instance](0398.md)

## Strict pre-event observations

Decision cutoff `1697635064801581429` receive nanoseconds; cursor cap `325547`. Eligible completed-group source `249550` was known by `1697635064800914566`, cursor `325535`. The family group itself is excluded.

| Measurement | Recorded value |
|---|---:|
| Best bid | 3.145000 |
| Best ask | 3.146000 |
| Midquote | 3.145500 |
| Spread | 0.001000 |
| Full bid size | 2042.000000 |
| Full ask size | 1347.000000 |
| Producer depth_n imbalance | -0.114551 |
| Full-book imbalance | 0.205075 |

| Pre-event rolling window | Buy-aggressor quantity | Sell-aggressor quantity |
|---:|---:|---:|
| 1 s | 0.000000 | 0.000000 |
| 5 s | 0.000000 | 0.000000 |
| 20 s | 1.000000 | 6.000000 |
| 60 s | 61.000000 | 45.000000 |
| 300 s | 612.000000 | 462.000000 |

These windows overlap. Values are the recorded quantities at the decision boundary; they do not identify the exact instant each pressure condition first became observable. Raw missingness/reasons and other contemporaneous measurements remain in the linked per-instance JSON and measurement ledger.

## Frozen forecasts and subsequently observed outcomes

### Signed endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | 0.000000 | 0.000000 | -0.001500 | 0.000500 | 0.002500 | -0.010000 | -0.018000 | -0.027000 | -0.042000 |
| Linear ridge | -0.000784 | -0.001260 | -0.001242 | -0.000493 | -0.003420 | 0.005299 | 0.009776 | 0.001111 | -0.003681 |
| Shallow trees | -0.000188 | -0.000055 | -0.000022 | 0.000876 | 0.000499 | 0.002607 | 0.001447 | -0.005913 | -0.004218 |
| Deeper trees | -0.000298 | -0.000630 | -0.000002 | 0.000450 | 0.000764 | 0.003388 | 0.002451 | -0.003572 | -0.002865 |
| Median-loss trees | 0.000141 | -0.000436 | -0.000200 | -0.000540 | -0.000725 | 0.000751 | 0.000254 | -0.004996 | -0.011694 |
| NeuralTree | -0.000073 | -0.000106 | 0.000033 | -0.000106 | 0.000316 | 0.000295 | 0.000361 | -0.000325 | 0.000844 |
| Residual MLP | 0.000783 | 0.001684 | 0.000761 | 0.001422 | 0.000734 | 0.006566 | 0.010266 | -0.004662 | -0.004885 |
| TabM | 0.000071 | -0.001000 | -0.000317 | -0.007601 | -0.003325 | 0.011678 | 0.016436 | 0.012093 | -0.027918 |
| Lower quantile | -0.000719 | -0.001146 | -0.001357 | -0.002831 | -0.001776 | -0.002016 | -0.003009 | -0.005970 | -0.010748 |
| Upper quantile | 0.001183 | 0.000611 | 0.000780 | 0.001894 | 0.002922 | 0.003750 | 0.006990 | 0.002277 | 0.005845 |

### Absolute endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | 0.000000 | 0.000000 | 0.001500 | 0.000500 | 0.002500 | 0.010000 | 0.018000 | 0.027000 | 0.042000 |
| Linear ridge | 0.001356 | 0.000742 | 0.000876 | 0.001438 | 0.002161 | 0.009501 | 0.013087 | 0.009357 | 0.012788 |
| Shallow trees | 0.001223 | 0.001091 | 0.001880 | 0.001409 | 0.001814 | 0.007210 | 0.009454 | 0.010160 | 0.007583 |
| Deeper trees | 0.000980 | 0.001042 | 0.002545 | 0.001493 | 0.002461 | 0.008043 | 0.012051 | 0.012849 | 0.009184 |
| Median-loss trees | 0.001096 | 0.000486 | 0.001706 | 0.002358 | 0.001779 | 0.005475 | 0.006032 | 0.006163 | 0.004754 |
| NeuralTree | 0.000656 | 0.000831 | 0.001116 | 0.001539 | 0.001759 | 0.002876 | 0.004147 | 0.006369 | 0.008029 |
| Residual MLP | 0.003201 | 0.002238 | 0.002302 | 0.003310 | 0.003174 | 0.011136 | 0.016115 | 0.005329 | 0.013275 |
| TabM | 0.000984 | 0.001836 | 0.001398 | 0.000873 | -0.009928 | -0.001915 | 0.002547 | 0.012733 | -0.001327 |
| Lower quantile | 0.000499 | 0.000703 | 0.000572 | 0.000573 | 0.001268 | 0.000985 | 0.002887 | 0.001753 | 0.002458 |
| Upper quantile | 0.001587 | 0.001496 | 0.002931 | 0.003430 | 0.002572 | 0.007060 | 0.009076 | 0.010566 | 0.011187 |

### Occurrence of any first-observed family for the instrument

| Perspective | 120 s | 300 s | 600 s |
|---|---:|---:|---:|
| **Observed later** | 1.000000 | 1.000000 | 1.000000 |
| Linear ridge | 0.469347 | 0.856790 | 0.596380 |
| Shallow trees | 0.823314 | 0.761640 | 0.958737 |
| Deeper trees | 0.857770 | 0.833050 | 0.958809 |
| NeuralTree | 0.582951 | 0.571087 | 0.574393 |
| Residual MLP | 0.985083 | 0.961094 | 0.860199 |
| TabM | 0.999443 | 0.997612 | 0.999679 |

Recorded held-out fold(s): 3. Original training chronology, family purge and embargo remain unchanged. Observed endpoints are hindsight labels, not predictors. A missing horizon remains unavailable. Quantile forecasts describe separate tails rather than competing point estimates. Negative magnitude forecasts are preserved as invalid outputs, without clipping.

## Source and interpretation boundaries

[Chronological index](../chronological-instance-index.csv) · [All pre-event forecasts and removal refits](../all-pre-event-forecasts.csv.gz) · [Individual JSON records](../individual-instance-records.jsonl.gz) · [Pre-event measurements](../pre-event-measurements.csv.gz) · [Clock receipts](../pre-event-clock-receipts.csv)

This is a first-observed structural family event, not a demonstrated original order birth, causal intervention or filled trade. Averages can provide context; an entry condition requires instance-specific timing, confirmation and invalidation evidence. Semantic coverage remains NOT_PASSED and neural repeatability/domain caveats remain unresolved.

No dedicated complete consecutive book replay has been generated for this instance. Some nearby events overlap the saved window centered on instance 375; the card itself contains context observations and horizon endpoints, not an invented continuous path.
