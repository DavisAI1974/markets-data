# Instance 5 individual market record

Family `ow-40540069fe5aeddc127b` · instrument `150611` · first observed **2023-10-17T22:00:00.339554943+00:00**.

[Previous instance](0004.md)
[Next instance](0006.md)

## Strict pre-event observations

Decision cutoff `1697580000339554942` receive nanoseconds; cursor cap `506`. Eligible completed-group source `108` was known by `1697580000339255053`, cursor `506`. The family group itself is excluded.

| Measurement | Recorded value |
|---|---:|
| Best bid | 3.061000 |
| Best ask | 3.064000 |
| Midquote | 3.062500 |
| Spread | 0.003000 |
| Full bid size | 862.000000 |
| Full ask size | 526.000000 |
| Producer depth_n imbalance | 0.130435 |
| Full-book imbalance | 0.242075 |

| Pre-event rolling window | Buy-aggressor quantity | Sell-aggressor quantity |
|---:|---:|---:|
| 1 s | 0.000000 | 0.000000 |
| 5 s | 0.000000 | 0.000000 |
| 20 s | 0.000000 | 0.000000 |
| 60 s | 0.000000 | 0.000000 |
| 300 s | 0.000000 | 0.000000 |

These windows overlap. Values are the recorded quantities at the decision boundary; they do not identify the exact instant each pressure condition first became observable. Raw missingness/reasons and other contemporaneous measurements remain in the linked per-instance JSON and measurement ledger.

## Frozen forecasts and subsequently observed outcomes

No saved held-out forecasts exist for this sample. The instance remains in the inventory; no in-sample or synthetic forecast is substituted.

## Source and interpretation boundaries

[Chronological index](../chronological-instance-index.csv) · [All pre-event forecasts and removal refits](../all-pre-event-forecasts.csv.gz) · [Individual JSON records](../individual-instance-records.jsonl.gz) · [Pre-event measurements](../pre-event-measurements.csv.gz) · [Clock receipts](../pre-event-clock-receipts.csv)

This is a first-observed structural family event, not a demonstrated original order birth, causal intervention or filled trade. Averages can provide context; an entry condition requires instance-specific timing, confirmation and invalidation evidence. Semantic coverage remains NOT_PASSED and neural repeatability/domain caveats remain unresolved.

No dedicated complete consecutive book replay has been generated for this instance. Some nearby events overlap the saved window centered on instance 375; the card itself contains context observations and horizon endpoints, not an invented continuous path.
