# Instance 511 individual market record

Family `ow-a48d343055552f8db14d` · instrument `150611` · first observed **2023-10-18T14:33:25.324713964+00:00**.

[Previous instance](0510.md)
[Next instance](0512.md)

## Strict pre-event observations

Decision cutoff `1697639605324713963` receive nanoseconds; cursor cap `447505`. Eligible completed-group source `341428` was known by `1697639605227669909`, cursor `447488`. The family group itself is excluded.

| Measurement | Recorded value |
|---|---:|
| Best bid | 3.106000 |
| Best ask | 3.108000 |
| Midquote | 3.107000 |
| Spread | 0.002000 |
| Full bid size | 2012.000000 |
| Full ask size | 1336.000000 |
| Producer depth_n imbalance | 0.029586 |
| Full-book imbalance | 0.201912 |

| Pre-event rolling window | Buy-aggressor quantity | Sell-aggressor quantity |
|---:|---:|---:|
| 1 s | 0.000000 | 0.000000 |
| 5 s | 8.000000 | 30.000000 |
| 20 s | 29.000000 | 40.000000 |
| 60 s | 37.000000 | 57.000000 |
| 300 s | 216.000000 | 187.000000 |

These windows overlap. Values are the recorded quantities at the decision boundary; they do not identify the exact instant each pressure condition first became observable. Raw missingness/reasons and other contemporaneous measurements remain in the linked per-instance JSON and measurement ledger.

## Frozen forecasts and subsequently observed outcomes

### Signed endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | -0.001500 | 0.000500 | -0.000500 | 0.000500 | -0.000500 | -0.001500 | -0.002500 | 0.016500 | -0.004500 |
| Linear ridge | -0.000815 | -0.001194 | -0.002306 | 0.001951 | -0.004638 | 0.005050 | 0.012147 | -0.003552 | -0.007387 |
| Shallow trees | -0.000779 | 0.000263 | 0.000364 | 0.000289 | -0.000409 | 0.004020 | 0.004339 | -0.004522 | -0.003733 |
| Deeper trees | -0.000305 | -0.000409 | -0.000097 | 0.000188 | -0.000592 | 0.004574 | 0.004432 | -0.003841 | -0.002471 |
| Median-loss trees | -0.000451 | 0.000029 | 0.000381 | 0.000393 | -0.000395 | 0.000926 | 0.000927 | -0.004036 | -0.003294 |
| NeuralTree | -0.000073 | -0.000106 | 0.000033 | -0.000106 | 0.000316 | 0.000295 | 0.000361 | -0.000325 | 0.000844 |
| Residual MLP | -0.000523 | 0.001003 | -0.003434 | -0.003073 | -0.002846 | 0.001404 | -0.003735 | -0.019016 | -0.020661 |
| TabM | 0.003396 | -0.003274 | -0.007164 | -0.007017 | -0.009930 | -0.004652 | 0.017883 | 0.013923 | -0.000532 |
| Lower quantile | -0.000230 | -0.000369 | -0.001118 | -0.001730 | -0.001803 | -0.002811 | -0.001703 | -0.004926 | -0.005108 |
| Upper quantile | 0.000579 | 0.000562 | 0.001397 | 0.002843 | 0.002256 | 0.003820 | 0.006951 | 0.002394 | 0.006297 |

### Absolute endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | 0.001500 | 0.000500 | 0.000500 | 0.000500 | 0.000500 | 0.001500 | 0.002500 | 0.016500 | 0.004500 |
| Linear ridge | 0.002344 | 0.001886 | 0.002430 | 0.003175 | 0.003179 | 0.010394 | 0.013777 | 0.009165 | 0.014247 |
| Shallow trees | 0.001830 | 0.002230 | 0.001132 | 0.001211 | 0.002124 | 0.007254 | 0.010145 | 0.010824 | 0.007116 |
| Deeper trees | 0.002119 | 0.001928 | 0.001265 | 0.001182 | 0.001903 | 0.008086 | 0.012583 | 0.012590 | 0.008284 |
| Median-loss trees | 0.001576 | 0.000835 | 0.001602 | 0.002441 | 0.002833 | 0.005521 | 0.004599 | 0.005637 | 0.004301 |
| NeuralTree | 0.000656 | 0.000831 | 0.001116 | 0.001539 | 0.001759 | 0.002876 | 0.004147 | 0.006369 | 0.008029 |
| Residual MLP | 0.001487 | 0.001796 | 0.002129 | 0.002805 | 0.006096 | 0.008017 | 0.004249 | 0.017886 | 0.032576 |
| TabM | -0.002133 | -0.000922 | 0.002147 | 0.006041 | -0.002686 | 0.012699 | 0.003381 | 0.044953 | 0.016888 |
| Lower quantile | 0.000620 | 0.000201 | 0.000492 | 0.000297 | 0.001057 | 0.000789 | 0.002543 | 0.001577 | 0.002469 |
| Upper quantile | 0.002173 | 0.001750 | 0.002551 | 0.003094 | 0.003453 | 0.006315 | 0.009272 | 0.010178 | 0.009863 |

### Occurrence of any first-observed family for the instrument

| Perspective | 120 s | 300 s | 600 s |
|---|---:|---:|---:|
| **Observed later** | 1.000000 | 1.000000 | 1.000000 |
| Linear ridge | 0.000001 | 0.999999 | 0.681978 |
| Shallow trees | 0.799933 | 0.860474 | 0.959648 |
| Deeper trees | 0.840901 | 0.864665 | 0.963380 |
| NeuralTree | 0.582844 | 0.570996 | 0.574511 |
| Residual MLP | 0.993880 | 0.961710 | 0.855217 |
| TabM | 0.999832 | 0.998176 | 0.999044 |

Recorded held-out fold(s): 3. Original training chronology, family purge and embargo remain unchanged. Observed endpoints are hindsight labels, not predictors. A missing horizon remains unavailable. Quantile forecasts describe separate tails rather than competing point estimates. Negative magnitude forecasts are preserved as invalid outputs, without clipping.

## Source and interpretation boundaries

[Chronological index](../chronological-instance-index.csv) · [All pre-event forecasts and removal refits](../all-pre-event-forecasts.csv.gz) · [Individual JSON records](../individual-instance-records.jsonl.gz) · [Pre-event measurements](../pre-event-measurements.csv.gz) · [Clock receipts](../pre-event-clock-receipts.csv)

This is a first-observed structural family event, not a demonstrated original order birth, causal intervention or filled trade. Averages can provide context; an entry condition requires instance-specific timing, confirmation and invalidation evidence. Semantic coverage remains NOT_PASSED and neural repeatability/domain caveats remain unresolved.

No dedicated complete consecutive book replay has been generated for this instance. Some nearby events overlap the saved window centered on instance 375; the card itself contains context observations and horizon endpoints, not an invented continuous path.
