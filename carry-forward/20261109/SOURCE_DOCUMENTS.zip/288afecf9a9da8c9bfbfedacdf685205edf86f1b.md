# Instance 47 individual market record

Family `ow-0fd740d2de1c39f5481d` · instrument `150611` · first observed **2023-10-17T23:00:00.000833870+00:00**.

[Previous instance](0046.md)
[Next instance](0048.md)

## Strict pre-event observations

Decision cutoff `1697583600000833869` receive nanoseconds; cursor cap `9099`. Eligible completed-group source `7397` was known by `1697583599136271118`, cursor `9098`. The family group itself is excluded.

| Measurement | Recorded value |
|---|---:|
| Best bid | 3.065000 |
| Best ask | 3.069000 |
| Midquote | 3.067000 |
| Spread | 0.004000 |
| Full bid size | 1038.000000 |
| Full ask size | 736.000000 |
| Producer depth_n imbalance | -0.592233 |
| Full-book imbalance | 0.170237 |

| Pre-event rolling window | Buy-aggressor quantity | Sell-aggressor quantity |
|---:|---:|---:|
| 1 s | 0.000000 | 0.000000 |
| 5 s | 0.000000 | 0.000000 |
| 20 s | 0.000000 | 0.000000 |
| 60 s | 4.000000 | 0.000000 |
| 300 s | 7.000000 | 2.000000 |

These windows overlap. Values are the recorded quantities at the decision boundary; they do not identify the exact instant each pressure condition first became observable. Raw missingness/reasons and other contemporaneous measurements remain in the linked per-instance JSON and measurement ledger.

## Frozen forecasts and subsequently observed outcomes

No saved held-out forecasts exist for this sample. The instance remains in the inventory; no in-sample or synthetic forecast is substituted.

## Source and interpretation boundaries

[Chronological index](../chronological-instance-index.csv) · [All pre-event forecasts and removal refits](../all-pre-event-forecasts.csv.gz) · [Individual JSON records](../individual-instance-records.jsonl.gz) · [Pre-event measurements](../pre-event-measurements.csv.gz) · [Clock receipts](../pre-event-clock-receipts.csv)

This is a first-observed structural family event, not a demonstrated original order birth, causal intervention or filled trade. Averages can provide context; an entry condition requires instance-specific timing, confirmation and invalidation evidence. Semantic coverage remains NOT_PASSED and neural repeatability/domain caveats remain unresolved.

No dedicated complete consecutive book replay has been generated for this instance. Some nearby events overlap the saved window centered on instance 375; the card itself contains context observations and horizon endpoints, not an invented continuous path.
