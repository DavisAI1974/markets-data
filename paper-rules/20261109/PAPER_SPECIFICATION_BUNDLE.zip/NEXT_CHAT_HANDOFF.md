# Continue this checkpoint

Start with README, machine/PAPER_UNIVERSE_MANIFEST.json, REMAINING_DEPENDENCIES.md and PUBLICATION_VERIFICATION.json. MARKET_DATA_INDEX.md at the repository root is central navigation. Earlier sources remain under carry-forward/20261109/.

User policy: carry everything forward; every hypothesis enters platform paper testing under the same process. No performance exclusion or observation-only promotion path. Keep everything in Git. Do not restart completed research workers. Keep E-to-Git migration paused. No historical strategy test substitutes for platform paper trades. Session scheduling is deferred. CME showed NGZ6; playback must match its actual contract/feed identity.

Progress: all 14,712 inherited source identities match pinned trees; zero task-prefix omissions in three branches. All 82 inherited candidates have continuation links. Finite broad/chain generators and October predicates/model identities/report cells are expanded. The core contains 32,701 records, not independent strategies. All execution is disabled. No platform fills occurred.

Recovered findings: full-depth FC screen; exact inverse versus flow-only mirror; ten continuous weakening/expiry predicates; causal one-lot onset context; documented/producer chain clocks; actual-known-by versus event time; midpoint/native feature distinction; historical price-sort defect. Canonical reanalysis has four model architectures, with two extra beyond M0/M1. Also recovered 117 constant states from full-precision original statistics. Exact evidence and source hashes are linked in RECOVERED_FINDINGS.md and reviews.

Helper corrections reject unavailable statuses, unbound definitions, outcome features, implicit-null imputation and same-timestamp future cursors. Initial midpoint units, transition precedence, cooldown and loss latch are now explicit. The helpers are not a full engine. Core records require full-definition hydration, including detector state, sampling and correction restrictions; never execute the stripped core alone.

Unfinished work: exact missing states, semantic/feature bindings, producers and order state machines, then a compiled platform adapter and actual simulation executions. Do not refit or substitute models as original recovery. CME custom JSON import is not established. NinjaTrader expects a NinjaScript import, not the specification ZIP. Full section/table-row semantic reconciliation is not certified.

The other analyst's previously excluded new reanalysis remains outside content review; allowed original documents and replication sources remain available. Preserve old evidence and verified correction history. Metadata or archive receipts do not prove semantic correctness or platform readiness.

Builders and validations are saved alongside outputs. Some original source-recovery builders reference local retained caches; generated artifacts and immutable source references are the portable checkpoint. Do not resume migration or old workers to reconstruct them.
