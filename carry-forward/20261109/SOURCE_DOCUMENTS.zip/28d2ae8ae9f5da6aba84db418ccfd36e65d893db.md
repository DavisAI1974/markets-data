# Instance 541 individual market record

Family `ow-6939335f9928a912d062` · instrument `150611` · first observed **2023-10-18T15:17:16.781645309+00:00**.

[Previous instance](0540.md)
[Next instance](0542.md)

## Strict pre-event observations

Decision cutoff `1697642236781645308` receive nanoseconds; cursor cap `492214`. Eligible completed-group source `375712` was known by `1697642233911009677`, cursor `492192`. The family group itself is excluded.

| Measurement | Recorded value |
|---|---:|
| Best bid | 3.109000 |
| Best ask | 3.110000 |
| Midquote | 3.109500 |
| Spread | 0.001000 |
| Full bid size | 2127.000000 |
| Full ask size | 1398.000000 |
| Producer depth_n imbalance | 0.010101 |
| Full-book imbalance | 0.206809 |

| Pre-event rolling window | Buy-aggressor quantity | Sell-aggressor quantity |
|---:|---:|---:|
| 1 s | 0.000000 | 0.000000 |
| 5 s | 0.000000 | 0.000000 |
| 20 s | 5.000000 | 0.000000 |
| 60 s | 44.000000 | 42.000000 |
| 300 s | 166.000000 | 189.000000 |

These windows overlap. Values are the recorded quantities at the decision boundary; they do not identify the exact instant each pressure condition first became observable. Raw missingness/reasons and other contemporaneous measurements remain in the linked per-instance JSON and measurement ledger.

## Frozen forecasts and subsequently observed outcomes

### Signed endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | 0.002000 | 0.002000 | 0.003000 | 0.004000 | 0.004000 | 0.002000 | 0.002000 | -0.024500 | -0.040000 |
| Linear ridge | 0.000021 | 0.001816 | 0.002156 | 0.000619 | 0.001906 | 0.007298 | 0.004529 | 0.005310 | 0.005387 |
| Shallow trees | 0.000641 | 0.000534 | 0.000145 | 0.001293 | 0.000585 | 0.004476 | 0.006351 | 0.003262 | -0.000161 |
| Deeper trees | 0.002185 | 0.000656 | -0.000176 | 0.002500 | 0.001201 | 0.003877 | 0.011072 | 0.004709 | -0.004550 |
| Median-loss trees | 0.000911 | 0.000782 | 0.000271 | 0.000518 | 0.001224 | 0.002988 | 0.008458 | 0.001593 | -0.000239 |
| NeuralTree | -0.000071 | -0.000094 | -0.000092 | -0.000007 | 0.000055 | 0.000447 | 0.000773 | -0.001183 | -0.005832 |
| Residual MLP | 0.001478 | 0.000936 | -0.000828 | 0.000127 | 0.003549 | 0.005066 | 0.006585 | 0.000845 | -0.018586 |
| TabM | -0.000066 | 0.000123 | -0.000251 | -0.000074 | 0.000418 | 0.001609 | 0.000987 | 0.002098 | -0.008362 |
| Lower quantile | -0.000799 | -0.001151 | -0.002046 | -0.002804 | -0.002646 | -0.003093 | -0.000398 | -0.004380 | -0.010229 |
| Upper quantile | 0.002752 | 0.002362 | 0.002128 | 0.003341 | 0.005993 | 0.009340 | 0.014119 | 0.012093 | 0.008447 |

### Absolute endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | 0.002000 | 0.002000 | 0.003000 | 0.004000 | 0.004000 | 0.002000 | 0.002000 | 0.024500 | 0.040000 |
| Linear ridge | 0.002009 | 0.001566 | 0.002244 | 0.002640 | 0.001824 | 0.001996 | 0.007505 | 0.008018 | 0.017372 |
| Shallow trees | 0.002094 | 0.001572 | 0.001835 | 0.002756 | 0.002782 | 0.006262 | 0.006332 | 0.009173 | 0.017361 |
| Deeper trees | 0.002433 | 0.002456 | 0.002183 | 0.002732 | 0.003096 | 0.007650 | 0.006851 | 0.011445 | 0.013395 |
| Median-loss trees | 0.001880 | 0.001535 | 0.002080 | 0.003150 | 0.002943 | 0.005488 | 0.007257 | 0.009501 | 0.017533 |
| NeuralTree | 0.001152 | 0.001264 | 0.001910 | 0.002814 | 0.003690 | 0.005544 | 0.008182 | 0.015028 | 0.022151 |
| Residual MLP | 0.001623 | 0.000826 | 0.001643 | 0.002964 | 0.002384 | 0.001674 | 0.004793 | 0.005758 | 0.020507 |
| TabM | 0.000910 | 0.001169 | 0.001800 | 0.002772 | 0.003589 | 0.005665 | 0.008195 | 0.013871 | 0.020409 |
| Lower quantile | 0.000499 | 0.000319 | 0.000608 | 0.000942 | 0.001091 | 0.002153 | 0.002333 | 0.003968 | 0.008081 |
| Upper quantile | 0.003142 | 0.003166 | 0.004022 | 0.005288 | 0.005182 | 0.008524 | 0.012672 | 0.015266 | 0.024984 |

### Occurrence of any first-observed family for the instrument

| Perspective | 120 s | 300 s | 600 s |
|---|---:|---:|---:|
| **Observed later** | 1.000000 | 1.000000 | 1.000000 |
| Linear ridge | 0.000001 | 0.999999 | 0.951276 |
| Shallow trees | 0.869743 | 0.935301 | 0.986266 |
| Deeper trees | 0.708563 | 0.943531 | 0.982803 |
| NeuralTree | 0.753390 | 0.764767 | 0.769651 |
| Residual MLP | 0.061422 | 0.990318 | 0.985430 |
| TabM | 0.074981 | 0.999999 | 0.999999 |

Recorded held-out fold(s): 4. Original training chronology, family purge and embargo remain unchanged. Observed endpoints are hindsight labels, not predictors. A missing horizon remains unavailable. Quantile forecasts describe separate tails rather than competing point estimates. Negative magnitude forecasts are preserved as invalid outputs, without clipping.

## Source and interpretation boundaries

[Chronological index](../chronological-instance-index.csv) · [All pre-event forecasts and removal refits](../all-pre-event-forecasts.csv.gz) · [Individual JSON records](../individual-instance-records.jsonl.gz) · [Pre-event measurements](../pre-event-measurements.csv.gz) · [Clock receipts](../pre-event-clock-receipts.csv)

This is a first-observed structural family event, not a demonstrated original order birth, causal intervention or filled trade. Averages can provide context; an entry condition requires instance-specific timing, confirmation and invalidation evidence. Semantic coverage remains NOT_PASSED and neural repeatability/domain caveats remain unresolved.

No dedicated complete consecutive book replay has been generated for this instance. Some nearby events overlap the saved window centered on instance 375; the card itself contains context observations and horizon endpoints, not an invented continuous path.
