# Instance 286 individual market record

Family `ow-763b20cb7271304f5c35` · instrument `150611` · first observed **2023-10-18T12:41:01.301721680+00:00**.

[Previous instance](0285.md)
[Next instance](0287.md)

## Strict pre-event observations

Decision cutoff `1697632861301721679` receive nanoseconds; cursor cap `237406`. Eligible completed-group source `186118` was known by `1697632861300512277`, cursor `237399`. The family group itself is excluded.

| Measurement | Recorded value |
|---|---:|
| Best bid | 3.127000 |
| Best ask | 3.130000 |
| Midquote | 3.128500 |
| Spread | 0.003000 |
| Full bid size | 2138.000000 |
| Full ask size | 1127.000000 |
| Producer depth_n imbalance | 0.048544 |
| Full-book imbalance | 0.309648 |

| Pre-event rolling window | Buy-aggressor quantity | Sell-aggressor quantity |
|---:|---:|---:|
| 1 s | 52.000000 | 0.000000 |
| 5 s | 53.000000 | 15.000000 |
| 20 s | 127.000000 | 45.000000 |
| 60 s | 149.000000 | 69.000000 |
| 300 s | 385.000000 | 209.000000 |

These windows overlap. Values are the recorded quantities at the decision boundary; they do not identify the exact instant each pressure condition first became observable. Raw missingness/reasons and other contemporaneous measurements remain in the linked per-instance JSON and measurement ledger.

## Frozen forecasts and subsequently observed outcomes

### Signed endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | 0.001000 | 0.001000 | 0.000500 | 0.001000 | 0.001000 | -0.001000 | -0.003500 | 0.017500 | -0.015000 |
| Linear ridge | -0.001765 | -0.002706 | -0.001987 | 0.001550 | -0.003765 | 0.002954 | 0.007307 | 0.000344 | -0.008529 |
| Shallow trees | -0.000158 | 0.000416 | 0.000167 | 0.000816 | -0.000319 | 0.002949 | 0.003285 | -0.003960 | -0.006207 |
| Deeper trees | 0.000279 | 0.000538 | -0.000074 | 0.000287 | -0.001158 | 0.005500 | 0.004012 | -0.004498 | -0.003563 |
| Median-loss trees | 0.000265 | 0.000404 | 0.000372 | -0.000269 | 0.000233 | 0.000162 | -0.000828 | -0.004607 | -0.008138 |
| NeuralTree | -0.000073 | -0.000106 | 0.000033 | -0.000106 | 0.000316 | 0.000295 | 0.000361 | -0.000325 | 0.000844 |
| Residual MLP | 0.001226 | 0.002441 | 0.000049 | 0.000742 | 0.000092 | 0.007174 | 0.011182 | -0.005738 | 0.004828 |
| TabM | 0.000624 | 0.000889 | 0.000280 | -0.001567 | -0.001116 | 0.005812 | 0.005877 | 0.016179 | -0.005719 |
| Lower quantile | -0.000455 | -0.001599 | -0.000988 | -0.002357 | -0.001485 | -0.002060 | -0.001852 | -0.005734 | -0.007707 |
| Upper quantile | 0.000889 | 0.001224 | 0.001488 | 0.001226 | 0.002687 | 0.004398 | 0.005996 | 0.003155 | 0.005272 |

### Absolute endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | 0.001000 | 0.001000 | 0.000500 | 0.001000 | 0.001000 | 0.001000 | 0.003500 | 0.017500 | 0.015000 |
| Linear ridge | -0.000043 | -0.000335 | -0.001030 | 0.001058 | 0.002829 | 0.005358 | 0.011283 | 0.008379 | 0.020991 |
| Shallow trees | 0.002942 | 0.001795 | 0.001531 | 0.002237 | 0.002721 | 0.004750 | 0.009469 | 0.010154 | 0.009872 |
| Deeper trees | 0.003054 | 0.002804 | 0.001892 | 0.002400 | 0.002491 | 0.005891 | 0.012307 | 0.013045 | 0.008805 |
| Median-loss trees | 0.001609 | 0.000917 | 0.001324 | 0.002421 | 0.002706 | 0.004504 | 0.006973 | 0.005371 | 0.006257 |
| NeuralTree | 0.000656 | 0.000831 | 0.001116 | 0.001539 | 0.001759 | 0.002876 | 0.004147 | 0.006369 | 0.008029 |
| Residual MLP | 0.001994 | 0.001906 | 0.001718 | 0.003369 | 0.004072 | 0.008959 | 0.012643 | 0.002138 | 0.015743 |
| TabM | 0.000931 | 0.000007 | 0.002026 | 0.002153 | 0.002560 | 0.006613 | 0.007545 | 0.014668 | 0.013072 |
| Lower quantile | 0.000620 | 0.000488 | 0.000539 | 0.000637 | 0.000826 | 0.000943 | 0.002717 | 0.001817 | 0.002513 |
| Upper quantile | 0.002373 | 0.001797 | 0.002146 | 0.002118 | 0.003966 | 0.006151 | 0.010758 | 0.009385 | 0.011228 |

### Occurrence of any first-observed family for the instrument

| Perspective | 120 s | 300 s | 600 s |
|---|---:|---:|---:|
| **Observed later** | 1.000000 | 1.000000 | 1.000000 |
| Linear ridge | 0.000001 | 0.999999 | 0.823388 |
| Shallow trees | 0.792170 | 0.811741 | 0.959648 |
| Deeper trees | 0.832343 | 0.838251 | 0.960343 |
| NeuralTree | 0.582936 | 0.571100 | 0.574345 |
| Residual MLP | 0.993150 | 0.955895 | 0.886771 |
| TabM | 0.999638 | 0.999442 | 0.999906 |

Recorded held-out fold(s): 3. Original training chronology, family purge and embargo remain unchanged. Observed endpoints are hindsight labels, not predictors. A missing horizon remains unavailable. Quantile forecasts describe separate tails rather than competing point estimates. Negative magnitude forecasts are preserved as invalid outputs, without clipping.

## Source and interpretation boundaries

[Chronological index](../chronological-instance-index.csv) · [All pre-event forecasts and removal refits](../all-pre-event-forecasts.csv.gz) · [Individual JSON records](../individual-instance-records.jsonl.gz) · [Pre-event measurements](../pre-event-measurements.csv.gz) · [Clock receipts](../pre-event-clock-receipts.csv)

This is a first-observed structural family event, not a demonstrated original order birth, causal intervention or filled trade. Averages can provide context; an entry condition requires instance-specific timing, confirmation and invalidation evidence. Semantic coverage remains NOT_PASSED and neural repeatability/domain caveats remain unresolved.

No dedicated complete consecutive book replay has been generated for this instance. Some nearby events overlap the saved window centered on instance 375; the card itself contains context observations and horizon endpoints, not an invented continuous path.
