# Instance 21 individual market record

Family `ow-b13ef7b8d0191e4e0d42` · instrument `150611` · first observed **2023-10-17T22:00:27.505374899+00:00**.

[Previous instance](0020.md)
[Next instance](0022.md)

## Strict pre-event observations

Decision cutoff `1697580027505374898` receive nanoseconds; cursor cap `1098`. Eligible completed-group source `565` was known by `1697580027208742992`, cursor `1096`. The family group itself is excluded.

| Measurement | Recorded value |
|---|---:|
| Best bid | 3.058000 |
| Best ask | 3.059000 |
| Midquote | 3.058500 |
| Spread | 0.001000 |
| Full bid size | 1003.000000 |
| Full ask size | 677.000000 |
| Producer depth_n imbalance | 0.408696 |
| Full-book imbalance | 0.194048 |

| Pre-event rolling window | Buy-aggressor quantity | Sell-aggressor quantity |
|---:|---:|---:|
| 1 s | 0.000000 | 0.000000 |
| 5 s | 0.000000 | 0.000000 |
| 20 s | 9.000000 | 5.000000 |
| 60 s | 24.000000 | 10.000000 |
| 300 s | 24.000000 | 10.000000 |

These windows overlap. Values are the recorded quantities at the decision boundary; they do not identify the exact instant each pressure condition first became observable. Raw missingness/reasons and other contemporaneous measurements remain in the linked per-instance JSON and measurement ledger.

## Frozen forecasts and subsequently observed outcomes

No saved held-out forecasts exist for this sample. The instance remains in the inventory; no in-sample or synthetic forecast is substituted.

## Source and interpretation boundaries

[Chronological index](../chronological-instance-index.csv) · [All pre-event forecasts and removal refits](../all-pre-event-forecasts.csv.gz) · [Individual JSON records](../individual-instance-records.jsonl.gz) · [Pre-event measurements](../pre-event-measurements.csv.gz) · [Clock receipts](../pre-event-clock-receipts.csv)

This is a first-observed structural family event, not a demonstrated original order birth, causal intervention or filled trade. Averages can provide context; an entry condition requires instance-specific timing, confirmation and invalidation evidence. Semantic coverage remains NOT_PASSED and neural repeatability/domain caveats remain unresolved.

No dedicated complete consecutive book replay has been generated for this instance. Some nearby events overlap the saved window centered on instance 375; the card itself contains context observations and horizon endpoints, not an invented continuous path.
