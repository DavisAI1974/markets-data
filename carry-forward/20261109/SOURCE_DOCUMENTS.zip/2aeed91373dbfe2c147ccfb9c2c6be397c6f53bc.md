# Instance 292 individual market record

Family `ow-2a6f552357ae2ea8c4c1` · instrument `150611` · first observed **2023-10-18T12:41:53.485858262+00:00**.

[Previous instance](0291.md)
[Next instance](0293.md)

## Strict pre-event observations

Decision cutoff `1697632913485858261` receive nanoseconds; cursor cap `239670`. Eligible completed-group source `187722` was known by `1697632913039431081`, cursor `239644`. The family group itself is excluded.

| Measurement | Recorded value |
|---|---:|
| Best bid | 3.129000 |
| Best ask | 3.130000 |
| Midquote | 3.129500 |
| Spread | 0.001000 |
| Full bid size | 2117.000000 |
| Full ask size | 1135.000000 |
| Producer depth_n imbalance | 0.024845 |
| Full-book imbalance | 0.301968 |

| Pre-event rolling window | Buy-aggressor quantity | Sell-aggressor quantity |
|---:|---:|---:|
| 1 s | 0.000000 | 0.000000 |
| 5 s | 5.000000 | 8.000000 |
| 20 s | 17.000000 | 34.000000 |
| 60 s | 214.000000 | 140.000000 |
| 300 s | 451.000000 | 293.000000 |

These windows overlap. Values are the recorded quantities at the decision boundary; they do not identify the exact instant each pressure condition first became observable. Raw missingness/reasons and other contemporaneous measurements remain in the linked per-instance JSON and measurement ledger.

## Frozen forecasts and subsequently observed outcomes

### Signed endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | 0.000000 | 0.000000 | 0.001000 | 0.000000 | 0.001000 | 0.000000 | -0.003000 | 0.020000 | -0.012000 |
| Linear ridge | -0.000809 | -0.001187 | -0.001592 | 0.001748 | -0.002480 | 0.003574 | 0.006582 | 0.001414 | -0.004924 |
| Shallow trees | -0.000259 | -0.000299 | 0.000286 | 0.001111 | 0.000435 | 0.001713 | 0.002739 | -0.003964 | -0.006988 |
| Deeper trees | -0.000523 | -0.000270 | -0.000412 | 0.000756 | 0.000144 | 0.004073 | 0.003612 | -0.004327 | -0.003641 |
| Median-loss trees | -0.000329 | 0.000077 | 0.000211 | 0.000010 | -0.000354 | -0.000088 | -0.000859 | -0.003651 | -0.008057 |
| NeuralTree | -0.000073 | -0.000106 | 0.000033 | -0.000106 | 0.000316 | 0.000295 | 0.000361 | -0.000325 | 0.000844 |
| Residual MLP | 0.000852 | 0.001661 | 0.000711 | 0.001334 | 0.000932 | 0.006105 | 0.010115 | -0.003017 | -0.004860 |
| TabM | -0.000350 | -0.001378 | -0.000465 | -0.003068 | 0.000876 | 0.013860 | 0.015841 | 0.012583 | -0.021471 |
| Lower quantile | -0.000887 | -0.001039 | -0.000937 | -0.001445 | -0.001528 | -0.001692 | -0.002093 | -0.005125 | -0.008103 |
| Upper quantile | 0.000725 | 0.000517 | 0.002804 | 0.001674 | 0.001390 | 0.004759 | 0.005377 | 0.003159 | 0.005305 |

### Absolute endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | 0.000000 | 0.000000 | 0.001000 | 0.000000 | 0.001000 | 0.000000 | 0.003000 | 0.020000 | 0.012000 |
| Linear ridge | -0.000469 | -0.001228 | -0.002064 | -0.000895 | -0.000640 | 0.006067 | 0.008997 | 0.003988 | 0.014926 |
| Shallow trees | 0.001288 | 0.001695 | 0.001428 | 0.001516 | 0.001856 | 0.005293 | 0.009517 | 0.011642 | 0.009030 |
| Deeper trees | 0.001835 | 0.002260 | 0.001906 | 0.001367 | 0.001854 | 0.006113 | 0.012610 | 0.013513 | 0.008586 |
| Median-loss trees | 0.000868 | 0.000856 | 0.001637 | 0.001955 | 0.002277 | 0.004553 | 0.005900 | 0.005377 | 0.005257 |
| NeuralTree | 0.000656 | 0.000831 | 0.001116 | 0.001539 | 0.001759 | 0.002876 | 0.004147 | 0.006369 | 0.008029 |
| Residual MLP | 0.003101 | 0.002255 | 0.002258 | 0.003284 | 0.003061 | 0.010453 | 0.015687 | 0.004537 | 0.013053 |
| TabM | 0.001321 | 0.001426 | 0.001248 | 0.002657 | -0.001462 | -0.004046 | 0.004321 | 0.012090 | 0.004852 |
| Lower quantile | -0.000005 | 0.000498 | 0.000401 | 0.000631 | 0.000491 | 0.000415 | 0.002423 | 0.001708 | 0.002656 |
| Upper quantile | 0.001698 | 0.002120 | 0.002018 | 0.002071 | 0.003603 | 0.005954 | 0.008697 | 0.009578 | 0.011106 |

### Occurrence of any first-observed family for the instrument

| Perspective | 120 s | 300 s | 600 s |
|---|---:|---:|---:|
| **Observed later** | 1.000000 | 1.000000 | 1.000000 |
| Linear ridge | 0.000001 | 0.999999 | 0.999999 |
| Shallow trees | 0.792170 | 0.834869 | 0.959648 |
| Deeper trees | 0.832343 | 0.880993 | 0.963494 |
| NeuralTree | 0.582933 | 0.571099 | 0.574352 |
| Residual MLP | 0.978131 | 0.960252 | 0.882467 |
| TabM | 0.998827 | 0.995173 | 0.999629 |

Recorded held-out fold(s): 3. Original training chronology, family purge and embargo remain unchanged. Observed endpoints are hindsight labels, not predictors. A missing horizon remains unavailable. Quantile forecasts describe separate tails rather than competing point estimates. Negative magnitude forecasts are preserved as invalid outputs, without clipping.

## Source and interpretation boundaries

[Chronological index](../chronological-instance-index.csv) · [All pre-event forecasts and removal refits](../all-pre-event-forecasts.csv.gz) · [Individual JSON records](../individual-instance-records.jsonl.gz) · [Pre-event measurements](../pre-event-measurements.csv.gz) · [Clock receipts](../pre-event-clock-receipts.csv)

This is a first-observed structural family event, not a demonstrated original order birth, causal intervention or filled trade. Averages can provide context; an entry condition requires instance-specific timing, confirmation and invalidation evidence. Semantic coverage remains NOT_PASSED and neural repeatability/domain caveats remain unresolved.

No dedicated complete consecutive book replay has been generated for this instance. Some nearby events overlap the saved window centered on instance 375; the card itself contains context observations and horizon endpoints, not an invented continuous path.
