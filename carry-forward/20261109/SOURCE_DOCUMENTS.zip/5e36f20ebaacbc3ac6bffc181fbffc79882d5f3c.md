# Instance 82 individual market record

Family `ow-3f0e532eaef8c2390812` · instrument `150611` · first observed **2023-10-18T02:30:32.251110622+00:00**.

[Previous instance](0081.md)
[Next instance](0083.md)

## Strict pre-event observations

Decision cutoff `1697596232251110621` receive nanoseconds; cursor cap `32279`. Eligible completed-group source `26486` was known by `1697596232224612584`, cursor `32269`. The family group itself is excluded.

| Measurement | Recorded value |
|---|---:|
| Best bid | 3.090000 |
| Best ask | 3.091000 |
| Midquote | 3.090500 |
| Spread | 0.001000 |
| Full bid size | 1277.000000 |
| Full ask size | 803.000000 |
| Producer depth_n imbalance | -0.080460 |
| Full-book imbalance | 0.227885 |

| Pre-event rolling window | Buy-aggressor quantity | Sell-aggressor quantity |
|---:|---:|---:|
| 1 s | 0.000000 | 0.000000 |
| 5 s | 1.000000 | 3.000000 |
| 20 s | 1.000000 | 3.000000 |
| 60 s | 1.000000 | 5.000000 |
| 300 s | 8.000000 | 9.000000 |

These windows overlap. Values are the recorded quantities at the decision boundary; they do not identify the exact instant each pressure condition first became observable. Raw missingness/reasons and other contemporaneous measurements remain in the linked per-instance JSON and measurement ledger.

## Frozen forecasts and subsequently observed outcomes

No saved held-out forecasts exist for this sample. The instance remains in the inventory; no in-sample or synthetic forecast is substituted.

## Source and interpretation boundaries

[Chronological index](../chronological-instance-index.csv) · [All pre-event forecasts and removal refits](../all-pre-event-forecasts.csv.gz) · [Individual JSON records](../individual-instance-records.jsonl.gz) · [Pre-event measurements](../pre-event-measurements.csv.gz) · [Clock receipts](../pre-event-clock-receipts.csv)

This is a first-observed structural family event, not a demonstrated original order birth, causal intervention or filled trade. Averages can provide context; an entry condition requires instance-specific timing, confirmation and invalidation evidence. Semantic coverage remains NOT_PASSED and neural repeatability/domain caveats remain unresolved.

No dedicated complete consecutive book replay has been generated for this instance. Some nearby events overlap the saved window centered on instance 375; the card itself contains context observations and horizon endpoints, not an invented continuous path.
