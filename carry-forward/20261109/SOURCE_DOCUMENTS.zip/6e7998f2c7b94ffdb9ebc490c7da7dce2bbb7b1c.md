# Instance 217 individual market record

Family `ow-f30387859d85f50f1cc6` · instrument `150611` · first observed **2023-10-18T11:38:28.615179575+00:00**.

[Previous instance](0216.md)
[Next instance](0218.md)

## Strict pre-event observations

Decision cutoff `1697629108615179574` receive nanoseconds; cursor cap `169610`. Eligible completed-group source `134715` was known by `1697629108614884222`, cursor `169605`. The family group itself is excluded.

| Measurement | Recorded value |
|---|---:|
| Best bid | 3.100000 |
| Best ask | 3.101000 |
| Midquote | 3.100500 |
| Spread | 0.001000 |
| Full bid size | 1699.000000 |
| Full ask size | 948.000000 |
| Producer depth_n imbalance | -0.027273 |
| Full-book imbalance | 0.283717 |

| Pre-event rolling window | Buy-aggressor quantity | Sell-aggressor quantity |
|---:|---:|---:|
| 1 s | 0.000000 | 6.000000 |
| 5 s | 14.000000 | 6.000000 |
| 20 s | 18.000000 | 22.000000 |
| 60 s | 26.000000 | 27.000000 |
| 300 s | 53.000000 | 56.000000 |

These windows overlap. Values are the recorded quantities at the decision boundary; they do not identify the exact instant each pressure condition first became observable. Raw missingness/reasons and other contemporaneous measurements remain in the linked per-instance JSON and measurement ledger.

## Frozen forecasts and subsequently observed outcomes

### Signed endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | -0.009000 | -0.009500 | -0.009500 | -0.009500 | -0.005500 | 0.000500 | 0.000500 | 0.007500 | 0.013000 |
| Linear ridge | -0.000980 | -0.001619 | -0.001990 | 0.002266 | -0.001787 | 0.002623 | 0.003303 | 0.001259 | -0.005310 |
| Shallow trees | -0.000185 | -0.000124 | -0.000150 | 0.000409 | -0.000312 | 0.001355 | 0.000552 | -0.005482 | -0.003085 |
| Deeper trees | -0.000248 | -0.000299 | -0.000255 | 0.000443 | -0.000324 | 0.002982 | 0.004465 | -0.004681 | -0.002909 |
| Median-loss trees | -0.000238 | 0.000006 | -0.000420 | 0.000380 | -0.000469 | 0.001309 | -0.002901 | -0.002469 | -0.007632 |
| NeuralTree | -0.000073 | -0.000106 | 0.000033 | -0.000106 | 0.000316 | 0.000295 | 0.000361 | -0.000325 | 0.000844 |
| Residual MLP | 0.000831 | 0.002694 | -0.000275 | 0.000269 | 0.000137 | 0.006635 | 0.005797 | -0.007922 | 0.004918 |
| TabM | 0.000915 | -0.000234 | -0.000725 | -0.001157 | -0.000846 | 0.005542 | -0.015500 | 0.016703 | -0.005172 |
| Lower quantile | -0.001284 | -0.001135 | -0.000916 | -0.001118 | -0.001714 | -0.002745 | -0.006123 | -0.006526 | -0.007136 |
| Upper quantile | 0.000376 | 0.000602 | 0.001538 | 0.001296 | 0.002084 | 0.004498 | 0.007276 | 0.002491 | 0.005573 |

### Absolute endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | 0.009000 | 0.009500 | 0.009500 | 0.009500 | 0.005500 | 0.000500 | 0.000500 | 0.007500 | 0.013000 |
| Linear ridge | 0.002382 | 0.002061 | 0.002334 | 0.003502 | 0.004981 | 0.008839 | 0.012837 | 0.013370 | 0.021479 |
| Shallow trees | 0.000436 | 0.000640 | 0.001585 | 0.001661 | 0.001932 | 0.007056 | 0.010054 | 0.009863 | 0.007371 |
| Deeper trees | 0.000669 | 0.001029 | 0.001751 | 0.001385 | 0.001362 | 0.008629 | 0.011379 | 0.013264 | 0.010482 |
| Median-loss trees | 0.000523 | 0.000816 | 0.001462 | 0.002339 | 0.002073 | 0.005487 | 0.008796 | 0.005940 | 0.003907 |
| NeuralTree | 0.000656 | 0.000831 | 0.001116 | 0.001539 | 0.001759 | 0.002876 | 0.004147 | 0.006369 | 0.008029 |
| Residual MLP | 0.002678 | 0.002295 | 0.001750 | 0.002970 | 0.003504 | 0.008632 | 0.010486 | 0.002713 | 0.014585 |
| TabM | 0.001139 | 0.000548 | 0.002138 | 0.001607 | 0.000731 | 0.006368 | 0.005505 | 0.016232 | 0.015797 |
| Lower quantile | 0.000119 | 0.000406 | 0.000503 | 0.000656 | 0.001254 | 0.002443 | 0.001884 | 0.002230 | 0.002314 |
| Upper quantile | 0.001184 | 0.001513 | 0.002469 | 0.002702 | 0.002592 | 0.007584 | 0.010320 | 0.009761 | 0.008139 |

### Occurrence of any first-observed family for the instrument

| Perspective | 120 s | 300 s | 600 s |
|---|---:|---:|---:|
| **Observed later** | 1.000000 | 1.000000 | 1.000000 |
| Linear ridge | 0.817386 | 0.987904 | 0.773371 |
| Shallow trees | 0.808421 | 0.836539 | 0.959648 |
| Deeper trees | 0.855354 | 0.843642 | 0.951689 |
| NeuralTree | 0.582891 | 0.571108 | 0.574279 |
| Residual MLP | 0.972999 | 0.951462 | 0.909163 |
| TabM | 0.998902 | 0.997219 | 0.999772 |

Recorded held-out fold(s): 3. Original training chronology, family purge and embargo remain unchanged. Observed endpoints are hindsight labels, not predictors. A missing horizon remains unavailable. Quantile forecasts describe separate tails rather than competing point estimates. Negative magnitude forecasts are preserved as invalid outputs, without clipping.

## Source and interpretation boundaries

[Chronological index](../chronological-instance-index.csv) · [All pre-event forecasts and removal refits](../all-pre-event-forecasts.csv.gz) · [Individual JSON records](../individual-instance-records.jsonl.gz) · [Pre-event measurements](../pre-event-measurements.csv.gz) · [Clock receipts](../pre-event-clock-receipts.csv)

This is a first-observed structural family event, not a demonstrated original order birth, causal intervention or filled trade. Averages can provide context; an entry condition requires instance-specific timing, confirmation and invalidation evidence. Semantic coverage remains NOT_PASSED and neural repeatability/domain caveats remain unresolved.

No dedicated complete consecutive book replay has been generated for this instance. Some nearby events overlap the saved window centered on instance 375; the card itself contains context observations and horizon endpoints, not an invented continuous path.
