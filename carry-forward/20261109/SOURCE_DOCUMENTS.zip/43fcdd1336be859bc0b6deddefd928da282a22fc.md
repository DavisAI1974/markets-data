# Instance 274 individual market record

Family `ow-bc05a53ee023ce9f818c` · instrument `150611` · first observed **2023-10-18T12:33:19.018713399+00:00**.

[Previous instance](0273.md)
[Next instance](0275.md)

## Strict pre-event observations

Decision cutoff `1697632399018713398` receive nanoseconds; cursor cap `228266`. Eligible completed-group source `179332` was known by `1697632398115536044`, cursor `228228`. The family group itself is excluded.

| Measurement | Recorded value |
|---|---:|
| Best bid | 3.116000 |
| Best ask | 3.117000 |
| Midquote | 3.116500 |
| Spread | 0.001000 |
| Full bid size | 2043.000000 |
| Full ask size | 1187.000000 |
| Producer depth_n imbalance | 0.098361 |
| Full-book imbalance | 0.265015 |

| Pre-event rolling window | Buy-aggressor quantity | Sell-aggressor quantity |
|---:|---:|---:|
| 1 s | 0.000000 | 0.000000 |
| 5 s | 19.000000 | 1.000000 |
| 20 s | 22.000000 | 1.000000 |
| 60 s | 67.000000 | 84.000000 |
| 300 s | 208.000000 | 184.000000 |

These windows overlap. Values are the recorded quantities at the decision boundary; they do not identify the exact instant each pressure condition first became observable. Raw missingness/reasons and other contemporaneous measurements remain in the linked per-instance JSON and measurement ledger.

## Frozen forecasts and subsequently observed outcomes

### Signed endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | -0.004500 | -0.004500 | -0.005000 | -0.008000 | -0.006000 | -0.001000 | 0.013000 | 0.026000 | 0.011500 |
| Linear ridge | -0.000952 | -0.002070 | -0.002053 | 0.000763 | -0.001916 | 0.002637 | 0.006646 | -0.001372 | -0.000464 |
| Shallow trees | -0.000388 | 0.000201 | 0.000571 | 0.000533 | 0.000018 | 0.003097 | 0.002694 | -0.003831 | -0.005215 |
| Deeper trees | -0.000569 | -0.000599 | 0.000627 | -0.000059 | -0.000167 | 0.003295 | 0.003312 | -0.002985 | -0.003147 |
| Median-loss trees | -0.000355 | 0.000191 | 0.000383 | 0.000501 | 0.000712 | 0.000170 | 0.000080 | -0.003257 | -0.011824 |
| NeuralTree | -0.000073 | -0.000106 | 0.000033 | -0.000106 | 0.000316 | 0.000295 | 0.000361 | -0.000325 | 0.000844 |
| Residual MLP | 0.001103 | 0.002678 | -0.000470 | 0.000484 | -0.000199 | 0.007164 | 0.006460 | -0.007470 | 0.005649 |
| TabM | 0.001014 | -0.000033 | -0.001160 | -0.001560 | -0.000240 | 0.006611 | -0.013297 | 0.017507 | -0.002794 |
| Lower quantile | -0.001582 | -0.001180 | -0.001054 | -0.001975 | -0.002136 | -0.001532 | -0.002372 | -0.005175 | -0.009471 |
| Upper quantile | 0.001103 | 0.001032 | 0.001674 | 0.002456 | 0.004032 | 0.004105 | 0.006732 | 0.002566 | 0.005359 |

### Absolute endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | 0.004500 | 0.004500 | 0.005000 | 0.008000 | 0.006000 | 0.001000 | 0.013000 | 0.026000 | 0.011500 |
| Linear ridge | 0.001824 | 0.001430 | 0.001234 | 0.002943 | 0.004744 | 0.009192 | 0.013917 | 0.012906 | 0.014383 |
| Shallow trees | 0.002632 | 0.002160 | 0.002375 | 0.002011 | 0.002434 | 0.007061 | 0.010057 | 0.011933 | 0.009964 |
| Deeper trees | 0.003270 | 0.002020 | 0.002801 | 0.002193 | 0.001828 | 0.007296 | 0.012074 | 0.013067 | 0.009386 |
| Median-loss trees | 0.001522 | 0.000891 | 0.002048 | 0.002220 | 0.002112 | 0.005103 | 0.006113 | 0.006318 | 0.004911 |
| NeuralTree | 0.000656 | 0.000831 | 0.001116 | 0.001539 | 0.001759 | 0.002876 | 0.004147 | 0.006369 | 0.008029 |
| Residual MLP | 0.002715 | 0.002274 | 0.001723 | 0.003124 | 0.003829 | 0.009125 | 0.011301 | 0.002050 | 0.015393 |
| TabM | 0.000994 | 0.000263 | 0.002625 | 0.001694 | 0.000548 | 0.006668 | 0.005083 | 0.016890 | 0.014479 |
| Lower quantile | 0.000499 | 0.000283 | 0.000506 | 0.000962 | 0.001362 | 0.000832 | 0.002859 | 0.002033 | 0.002509 |
| Upper quantile | 0.002378 | 0.001612 | 0.002246 | 0.002646 | 0.003052 | 0.006321 | 0.009403 | 0.010298 | 0.010816 |

### Occurrence of any first-observed family for the instrument

| Perspective | 120 s | 300 s | 600 s |
|---|---:|---:|---:|
| **Observed later** | 1.000000 | 1.000000 | 1.000000 |
| Linear ridge | 0.000001 | 0.999999 | 0.999999 |
| Shallow trees | 0.806946 | 0.845861 | 0.959648 |
| Deeper trees | 0.846867 | 0.854637 | 0.960343 |
| NeuralTree | 0.582947 | 0.571117 | 0.574357 |
| Residual MLP | 0.980041 | 0.961485 | 0.879644 |
| TabM | 0.998752 | 0.997647 | 0.999778 |

Recorded held-out fold(s): 3. Original training chronology, family purge and embargo remain unchanged. Observed endpoints are hindsight labels, not predictors. A missing horizon remains unavailable. Quantile forecasts describe separate tails rather than competing point estimates. Negative magnitude forecasts are preserved as invalid outputs, without clipping.

## Source and interpretation boundaries

[Chronological index](../chronological-instance-index.csv) · [All pre-event forecasts and removal refits](../all-pre-event-forecasts.csv.gz) · [Individual JSON records](../individual-instance-records.jsonl.gz) · [Pre-event measurements](../pre-event-measurements.csv.gz) · [Clock receipts](../pre-event-clock-receipts.csv)

This is a first-observed structural family event, not a demonstrated original order birth, causal intervention or filled trade. Averages can provide context; an entry condition requires instance-specific timing, confirmation and invalidation evidence. Semantic coverage remains NOT_PASSED and neural repeatability/domain caveats remain unresolved.

No dedicated complete consecutive book replay has been generated for this instance. Some nearby events overlap the saved window centered on instance 375; the card itself contains context observations and horizon endpoints, not an invented continuous path.
