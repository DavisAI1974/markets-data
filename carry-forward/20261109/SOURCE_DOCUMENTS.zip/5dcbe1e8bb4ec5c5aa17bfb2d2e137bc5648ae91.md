# Instance 121 individual market record

Family `ow-fd0fa2e059b6815bc69d` · instrument `150611` · first observed **2023-10-18T06:57:34.928058420+00:00**.

[Previous instance](0120.md)
[Next instance](0122.md)

## Strict pre-event observations

Decision cutoff `1697612254928058419` receive nanoseconds; cursor cap `63649`. Eligible completed-group source `52187` was known by `1697612239695397651`, cursor `63645`. The family group itself is excluded.

| Measurement | Recorded value |
|---|---:|
| Best bid | 3.060000 |
| Best ask | 3.061000 |
| Midquote | 3.060500 |
| Spread | 0.001000 |
| Full bid size | 1285.000000 |
| Full ask size | 1054.000000 |
| Producer depth_n imbalance | -0.142857 |
| Full-book imbalance | 0.098760 |

| Pre-event rolling window | Buy-aggressor quantity | Sell-aggressor quantity |
|---:|---:|---:|
| 1 s | 0.000000 | 0.000000 |
| 5 s | 0.000000 | 0.000000 |
| 20 s | 0.000000 | 2.000000 |
| 60 s | 2.000000 | 2.000000 |
| 300 s | 20.000000 | 23.000000 |

These windows overlap. Values are the recorded quantities at the decision boundary; they do not identify the exact instant each pressure condition first became observable. Raw missingness/reasons and other contemporaneous measurements remain in the linked per-instance JSON and measurement ledger.

## Frozen forecasts and subsequently observed outcomes

### Signed endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | unavailable | unavailable | unavailable | unavailable | unavailable | unavailable | unavailable | unavailable | unavailable |

### Absolute endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | unavailable | unavailable | unavailable | unavailable | unavailable | unavailable | unavailable | unavailable | unavailable |

### Occurrence of any first-observed family for the instrument

| Perspective | 120 s | 300 s | 600 s |
|---|---:|---:|---:|
| **Observed later** | 1.000000 | 1.000000 | 1.000000 |
| Linear ridge | 0.999999 | 0.715148 | 0.999999 |
| Shallow trees | 0.787522 | 0.825566 | 0.958006 |
| Deeper trees | 0.859080 | 0.848493 | 0.951650 |
| NeuralTree | 0.535902 | 0.536684 | 0.536927 |
| Residual MLP | 0.287440 | 0.091800 | 0.910417 |
| TabM | 0.450946 | 0.039132 | 0.874073 |

Recorded held-out fold(s): 2. Original training chronology, family purge and embargo remain unchanged. Observed endpoints are hindsight labels, not predictors. A missing horizon remains unavailable. Quantile forecasts describe separate tails rather than competing point estimates. Negative magnitude forecasts are preserved as invalid outputs, without clipping.

## Source and interpretation boundaries

[Chronological index](../chronological-instance-index.csv) · [All pre-event forecasts and removal refits](../all-pre-event-forecasts.csv.gz) · [Individual JSON records](../individual-instance-records.jsonl.gz) · [Pre-event measurements](../pre-event-measurements.csv.gz) · [Clock receipts](../pre-event-clock-receipts.csv)

This is a first-observed structural family event, not a demonstrated original order birth, causal intervention or filled trade. Averages can provide context; an entry condition requires instance-specific timing, confirmation and invalidation evidence. Semantic coverage remains NOT_PASSED and neural repeatability/domain caveats remain unresolved.

No dedicated complete consecutive book replay has been generated for this instance. Some nearby events overlap the saved window centered on instance 375; the card itself contains context observations and horizon endpoints, not an invented continuous path.
