# Instance 369 individual market record

Family `ow-0ce41599cab3797d14db` · instrument `150611` · first observed **2023-10-18T13:06:05.786073142+00:00**.

[Previous instance](0368.md)
[Next instance](0370.md)

## Strict pre-event observations

Decision cutoff `1697634365786073141` receive nanoseconds; cursor cap `294892`. Eligible completed-group source `226997` was known by `1697634365783749799`, cursor `294871`. The family group itself is excluded.

| Measurement | Recorded value |
|---|---:|
| Best bid | 3.153000 |
| Best ask | 3.155000 |
| Midquote | 3.154000 |
| Spread | 0.002000 |
| Full bid size | 2174.000000 |
| Full ask size | 1142.000000 |
| Producer depth_n imbalance | 0.169713 |
| Full-book imbalance | 0.311218 |

| Pre-event rolling window | Buy-aggressor quantity | Sell-aggressor quantity |
|---:|---:|---:|
| 1 s | 0.000000 | 2.000000 |
| 5 s | 33.000000 | 16.000000 |
| 20 s | 129.000000 | 75.000000 |
| 60 s | 410.000000 | 198.000000 |
| 300 s | 1464.000000 | 1370.000000 |

These windows overlap. Values are the recorded quantities at the decision boundary; they do not identify the exact instant each pressure condition first became observable. Raw missingness/reasons and other contemporaneous measurements remain in the linked per-instance JSON and measurement ledger.

## Frozen forecasts and subsequently observed outcomes

### Signed endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | -0.000500 | -0.000500 | -0.001000 | -0.000500 | -0.001000 | -0.007500 | -0.007500 | -0.026500 | -0.049500 |
| Linear ridge | -0.001467 | -0.001674 | -0.001799 | -0.000593 | -0.004895 | 0.007237 | 0.006361 | -0.000233 | -0.002243 |
| Shallow trees | 0.000076 | 0.000069 | 0.000737 | -0.000388 | -0.000219 | 0.003658 | 0.004071 | -0.005542 | -0.003778 |
| Deeper trees | 0.000028 | 0.000172 | 0.000612 | -0.000672 | -0.000248 | 0.005711 | 0.004872 | -0.005139 | -0.002108 |
| Median-loss trees | 0.000708 | 0.000823 | 0.000806 | -0.000479 | 0.000350 | 0.000930 | -0.000226 | -0.005196 | -0.006429 |
| NeuralTree | -0.000073 | -0.000106 | 0.000033 | -0.000106 | 0.000316 | 0.000295 | 0.000361 | -0.000325 | 0.000844 |
| Residual MLP | 0.000726 | 0.001858 | 0.000706 | 0.001238 | 0.000629 | 0.006298 | 0.009943 | -0.002234 | -0.003982 |
| TabM | -0.000287 | -0.001579 | -0.001285 | -0.003528 | -0.000887 | 0.016079 | 0.016894 | 0.014778 | -0.030293 |
| Lower quantile | -0.000625 | -0.001465 | -0.001569 | -0.001077 | -0.001205 | -0.001376 | -0.001690 | -0.009558 | -0.008243 |
| Upper quantile | 0.001998 | 0.002071 | 0.002411 | 0.001831 | 0.001372 | 0.004634 | 0.005883 | 0.002604 | 0.005685 |

### Absolute endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | 0.000500 | 0.000500 | 0.001000 | 0.000500 | 0.001000 | 0.007500 | 0.007500 | 0.026500 | 0.049500 |
| Linear ridge | -0.000171 | -0.000036 | -0.003049 | -0.000968 | -0.000673 | 0.006487 | 0.012449 | 0.008008 | 0.011010 |
| Shallow trees | 0.001653 | 0.002383 | 0.001919 | 0.001959 | 0.001724 | 0.004990 | 0.009562 | 0.011888 | 0.009262 |
| Deeper trees | 0.001502 | 0.003025 | 0.002326 | 0.001640 | 0.002063 | 0.005378 | 0.012322 | 0.012434 | 0.010120 |
| Median-loss trees | 0.001349 | 0.001215 | 0.002314 | 0.001771 | 0.001306 | 0.004903 | 0.006177 | 0.006496 | 0.005343 |
| NeuralTree | 0.000656 | 0.000831 | 0.001116 | 0.001539 | 0.001759 | 0.002876 | 0.004147 | 0.006369 | 0.008029 |
| Residual MLP | 0.003023 | 0.002432 | 0.002287 | 0.003424 | 0.003212 | 0.010788 | 0.016569 | 0.004656 | 0.012935 |
| TabM | 0.001265 | 0.001438 | 0.000854 | 0.002063 | -0.001694 | -0.004842 | 0.003308 | 0.011368 | 0.003229 |
| Lower quantile | 0.000240 | 0.000201 | 0.000586 | 0.000470 | 0.000552 | 0.002184 | 0.002162 | 0.002027 | 0.003026 |
| Upper quantile | 0.001562 | 0.001422 | 0.002445 | 0.001829 | 0.002448 | 0.006003 | 0.009961 | 0.012592 | 0.011349 |

### Occurrence of any first-observed family for the instrument

| Perspective | 120 s | 300 s | 600 s |
|---|---:|---:|---:|
| **Observed later** | 1.000000 | 1.000000 | 1.000000 |
| Linear ridge | 0.000001 | 0.999999 | 0.529971 |
| Shallow trees | 0.814156 | 0.830080 | 0.880515 |
| Deeper trees | 0.856768 | 0.876768 | 0.827159 |
| NeuralTree | 0.582981 | 0.571107 | 0.574400 |
| Residual MLP | 0.986824 | 0.959538 | 0.871528 |
| TabM | 0.999264 | 0.992424 | 0.999845 |

Recorded held-out fold(s): 3. Original training chronology, family purge and embargo remain unchanged. Observed endpoints are hindsight labels, not predictors. A missing horizon remains unavailable. Quantile forecasts describe separate tails rather than competing point estimates. Negative magnitude forecasts are preserved as invalid outputs, without clipping.

## Source and interpretation boundaries

[Chronological index](../chronological-instance-index.csv) · [All pre-event forecasts and removal refits](../all-pre-event-forecasts.csv.gz) · [Individual JSON records](../individual-instance-records.jsonl.gz) · [Pre-event measurements](../pre-event-measurements.csv.gz) · [Clock receipts](../pre-event-clock-receipts.csv)

This is a first-observed structural family event, not a demonstrated original order birth, causal intervention or filled trade. Averages can provide context; an entry condition requires instance-specific timing, confirmation and invalidation evidence. Semantic coverage remains NOT_PASSED and neural repeatability/domain caveats remain unresolved.

No dedicated complete consecutive book replay has been generated for this instance. Some nearby events overlap the saved window centered on instance 375; the card itself contains context observations and horizon endpoints, not an invented continuous path.
