# Instance 534 individual market record

Family `ow-04a2a6c16a6930d0ee75` · instrument `150611` · first observed **2023-10-18T15:08:39.086959052+00:00**.

[Previous instance](0533.md)
[Next instance](0535.md)

## Strict pre-event observations

Decision cutoff `1697641719086959051` receive nanoseconds; cursor cap `483670`. Eligible completed-group source `369363` was known by `1697641716112251545`, cursor `483658`. The family group itself is excluded.

| Measurement | Recorded value |
|---|---:|
| Best bid | 3.115000 |
| Best ask | 3.116000 |
| Midquote | 3.115500 |
| Spread | 0.001000 |
| Full bid size | 2030.000000 |
| Full ask size | 1374.000000 |
| Producer depth_n imbalance | 0.035144 |
| Full-book imbalance | 0.192714 |

| Pre-event rolling window | Buy-aggressor quantity | Sell-aggressor quantity |
|---:|---:|---:|
| 1 s | 0.000000 | 0.000000 |
| 5 s | 0.000000 | 0.000000 |
| 20 s | 6.000000 | 6.000000 |
| 60 s | 32.000000 | 29.000000 |
| 300 s | 194.000000 | 265.000000 |

These windows overlap. Values are the recorded quantities at the decision boundary; they do not identify the exact instant each pressure condition first became observable. Raw missingness/reasons and other contemporaneous measurements remain in the linked per-instance JSON and measurement ledger.

## Frozen forecasts and subsequently observed outcomes

### Signed endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | -0.001000 | -0.001000 | -0.000500 | 0.000000 | -0.003000 | -0.009000 | unavailable | -0.018000 | -0.032000 |
| Linear ridge | -0.000826 | -0.001025 | -0.002065 | 0.001318 | -0.006492 | 0.003744 | unavailable | -0.004150 | -0.009358 |
| Shallow trees | 0.000585 | 0.000381 | 0.000029 | 0.000847 | -0.000417 | 0.000743 | unavailable | -0.005106 | -0.003726 |
| Deeper trees | 0.001277 | 0.000710 | 0.000415 | 0.000888 | -0.000258 | 0.001375 | unavailable | -0.004001 | -0.001895 |
| Median-loss trees | -0.000347 | -0.000596 | 0.000543 | -0.000350 | -0.000816 | 0.000391 | unavailable | -0.005491 | -0.001961 |
| NeuralTree | -0.000073 | -0.000106 | 0.000033 | -0.000106 | 0.000316 | 0.000295 | unavailable | -0.000325 | 0.000844 |
| Residual MLP | -0.000502 | 0.001126 | -0.003565 | -0.003289 | -0.002990 | 0.001284 | unavailable | -0.018907 | -0.019825 |
| TabM | 0.003563 | -0.003517 | -0.007678 | -0.007560 | -0.010950 | -0.002959 | unavailable | 0.013785 | -0.004413 |
| Lower quantile | -0.000908 | -0.000521 | -0.001153 | -0.001214 | -0.001660 | -0.002014 | unavailable | -0.006605 | -0.007299 |
| Upper quantile | 0.001108 | 0.000745 | 0.001641 | 0.001213 | 0.001180 | 0.003025 | unavailable | 0.002381 | 0.005719 |

### Absolute endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | 0.001000 | 0.001000 | 0.000500 | 0.000000 | 0.003000 | 0.009000 | unavailable | 0.018000 | 0.032000 |
| Linear ridge | 0.002537 | 0.001881 | 0.002270 | 0.002628 | 0.002776 | 0.009235 | unavailable | 0.009485 | 0.012536 |
| Shallow trees | 0.002154 | 0.001904 | 0.001902 | 0.001565 | 0.001941 | 0.005627 | unavailable | 0.009755 | 0.006755 |
| Deeper trees | 0.002228 | 0.002203 | 0.002201 | 0.001475 | 0.002231 | 0.006728 | unavailable | 0.010460 | 0.007866 |
| Median-loss trees | 0.001978 | 0.001036 | 0.001566 | 0.001815 | 0.002204 | 0.004827 | unavailable | 0.006776 | 0.004806 |
| NeuralTree | 0.000656 | 0.000831 | 0.001116 | 0.001539 | 0.001759 | 0.002876 | unavailable | 0.006369 | 0.008029 |
| Residual MLP | 0.001495 | 0.001771 | 0.002142 | 0.002941 | 0.006144 | 0.008034 | unavailable | 0.017627 | 0.032527 |
| TabM | -0.001947 | -0.000827 | 0.002074 | 0.006047 | -0.002419 | 0.013612 | unavailable | 0.044949 | 0.016332 |
| Lower quantile | 0.000379 | 0.000191 | 0.000526 | 0.000617 | 0.000314 | 0.001113 | unavailable | 0.001383 | 0.003243 |
| Upper quantile | 0.002772 | 0.002114 | 0.002981 | 0.002301 | 0.003771 | 0.007297 | unavailable | 0.011967 | 0.007899 |

### Occurrence of any first-observed family for the instrument

| Perspective | 120 s | 300 s | 600 s |
|---|---:|---:|---:|
| **Observed later** | 1.000000 | 1.000000 | 1.000000 |
| Linear ridge | 0.000001 | 0.335870 | 0.556413 |
| Shallow trees | 0.823314 | 0.854217 | 0.959648 |
| Deeper trees | 0.861492 | 0.897697 | 0.955880 |
| NeuralTree | 0.582849 | 0.570998 | 0.574551 |
| Residual MLP | 0.992093 | 0.957886 | 0.853265 |
| TabM | 0.999544 | 0.988846 | 0.999102 |

Recorded held-out fold(s): 3. Original training chronology, family purge and embargo remain unchanged. Observed endpoints are hindsight labels, not predictors. A missing horizon remains unavailable. Quantile forecasts describe separate tails rather than competing point estimates. Negative magnitude forecasts are preserved as invalid outputs, without clipping.

## Source and interpretation boundaries

[Chronological index](../chronological-instance-index.csv) · [All pre-event forecasts and removal refits](../all-pre-event-forecasts.csv.gz) · [Individual JSON records](../individual-instance-records.jsonl.gz) · [Pre-event measurements](../pre-event-measurements.csv.gz) · [Clock receipts](../pre-event-clock-receipts.csv)

This is a first-observed structural family event, not a demonstrated original order birth, causal intervention or filled trade. Averages can provide context; an entry condition requires instance-specific timing, confirmation and invalidation evidence. Semantic coverage remains NOT_PASSED and neural repeatability/domain caveats remain unresolved.

No dedicated complete consecutive book replay has been generated for this instance. Some nearby events overlap the saved window centered on instance 375; the card itself contains context observations and horizon endpoints, not an invented continuous path.
