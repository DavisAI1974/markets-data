# Instance 583 individual market record

Family `ow-d3002497cbb38b67e186` · instrument `150611` · first observed **2023-10-18T16:14:01.406672942+00:00**.

[Previous instance](0582.md)
[Next instance](0584.md)

## Strict pre-event observations

Decision cutoff `1697645641406672941` receive nanoseconds; cursor cap `537947`. Eligible completed-group source `409494` was known by `1697645641400072826`, cursor `537880`. The family group itself is excluded.

| Measurement | Recorded value |
|---|---:|
| Best bid | 3.075000 |
| Best ask | 3.076000 |
| Midquote | 3.075500 |
| Spread | 0.001000 |
| Full bid size | 1756.000000 |
| Full ask size | 1652.000000 |
| Producer depth_n imbalance | -0.235023 |
| Full-book imbalance | 0.030516 |

| Pre-event rolling window | Buy-aggressor quantity | Sell-aggressor quantity |
|---:|---:|---:|
| 1 s | 5.000000 | 140.000000 |
| 5 s | 15.000000 | 140.000000 |
| 20 s | 15.000000 | 165.000000 |
| 60 s | 52.000000 | 186.000000 |
| 300 s | 161.000000 | 311.000000 |

These windows overlap. Values are the recorded quantities at the decision boundary; they do not identify the exact instant each pressure condition first became observable. Raw missingness/reasons and other contemporaneous measurements remain in the linked per-instance JSON and measurement ledger.

## Frozen forecasts and subsequently observed outcomes

### Signed endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | -0.002000 | -0.002500 | -0.004000 | -0.004000 | -0.003000 | -0.005000 | -0.009000 | -0.003000 | 0.007000 |
| Linear ridge | 0.000935 | 0.001887 | 0.007773 | 0.007828 | 0.007182 | 0.008339 | 0.013653 | 0.015100 | 0.008523 |
| Shallow trees | -0.000532 | -0.000179 | -0.000668 | -0.000201 | 0.001684 | 0.001649 | 0.004760 | 0.006020 | 0.002965 |
| Deeper trees | -0.000776 | -0.000443 | 0.000227 | 0.000365 | 0.002047 | 0.003377 | 0.010576 | 0.008049 | -0.005285 |
| Median-loss trees | -0.001218 | -0.000926 | 0.000051 | 0.000707 | 0.001491 | 0.002844 | 0.002461 | 0.000941 | -0.000072 |
| NeuralTree | -0.000071 | -0.000094 | -0.000092 | -0.000007 | 0.000055 | 0.000447 | 0.000773 | -0.001196 | -0.005865 |
| Residual MLP | -0.000287 | 0.001138 | -0.001875 | 0.002582 | 0.003875 | 0.008727 | 0.001619 | 0.013653 | -0.023559 |
| TabM | 0.000056 | 0.000099 | -0.000237 | 0.000265 | 0.000623 | 0.000601 | 0.000530 | 0.001510 | -0.011737 |
| Lower quantile | -0.002371 | -0.002483 | -0.003569 | -0.002733 | -0.002483 | -0.002826 | -0.002276 | -0.007038 | -0.013827 |
| Upper quantile | 0.000788 | 0.001178 | 0.002315 | 0.004106 | 0.005928 | 0.009172 | 0.009730 | 0.011338 | 0.004777 |

### Absolute endpoint midquote change

| Perspective | 1 s | 5 s | 20 s | 60 s | 120 s | 300 s | 600 s | 1800 s | 3600 s |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| **Observed later** | 0.002000 | 0.002500 | 0.004000 | 0.004000 | 0.003000 | 0.005000 | 0.009000 | 0.003000 | 0.007000 |
| Linear ridge | 0.001866 | 0.000928 | 0.002714 | 0.004280 | 0.005844 | 0.006348 | 0.003467 | 0.009737 | 0.018743 |
| Shallow trees | 0.002121 | 0.002237 | 0.002403 | 0.002177 | 0.002794 | 0.004076 | 0.006538 | 0.012942 | 0.014801 |
| Deeper trees | 0.002199 | 0.002017 | 0.002319 | 0.002500 | 0.002862 | 0.003818 | 0.007803 | 0.011171 | 0.012425 |
| Median-loss trees | 0.001749 | 0.001630 | 0.001730 | 0.002372 | 0.003235 | 0.005097 | 0.007506 | 0.010829 | 0.012601 |
| NeuralTree | 0.001160 | 0.001286 | 0.001918 | 0.002834 | 0.003717 | 0.005549 | 0.008152 | 0.014944 | 0.022349 |
| Residual MLP | 0.000994 | 0.001128 | 0.001111 | 0.002971 | 0.003022 | 0.004800 | 0.005731 | 0.014159 | 0.016927 |
| TabM | 0.001153 | 0.001322 | 0.001885 | 0.003082 | 0.003386 | 0.006121 | 0.007281 | 0.014782 | 0.020667 |
| Lower quantile | 0.000432 | 0.000410 | 0.000741 | 0.000954 | 0.000732 | 0.002043 | 0.002485 | 0.010192 | 0.007675 |
| Upper quantile | 0.002765 | 0.003468 | 0.003682 | 0.004554 | 0.005496 | 0.008279 | 0.009083 | 0.015028 | 0.019134 |

### Occurrence of any first-observed family for the instrument

| Perspective | 120 s | 300 s | 600 s |
|---|---:|---:|---:|
| **Observed later** | 1.000000 | 1.000000 | 1.000000 |
| Linear ridge | 0.296151 | 0.695098 | 0.999999 |
| Shallow trees | 0.864697 | 0.912548 | 0.986101 |
| Deeper trees | 0.863669 | 0.937331 | 0.983109 |
| NeuralTree | 0.753956 | 0.764857 | 0.769630 |
| Residual MLP | 0.125582 | 0.988673 | 0.990371 |
| TabM | 0.744013 | 0.999999 | 0.999999 |

Recorded held-out fold(s): 4. Original training chronology, family purge and embargo remain unchanged. Observed endpoints are hindsight labels, not predictors. A missing horizon remains unavailable. Quantile forecasts describe separate tails rather than competing point estimates. Negative magnitude forecasts are preserved as invalid outputs, without clipping.

## Source and interpretation boundaries

[Chronological index](../chronological-instance-index.csv) · [All pre-event forecasts and removal refits](../all-pre-event-forecasts.csv.gz) · [Individual JSON records](../individual-instance-records.jsonl.gz) · [Pre-event measurements](../pre-event-measurements.csv.gz) · [Clock receipts](../pre-event-clock-receipts.csv)

This is a first-observed structural family event, not a demonstrated original order birth, causal intervention or filled trade. Averages can provide context; an entry condition requires instance-specific timing, confirmation and invalidation evidence. Semantic coverage remains NOT_PASSED and neural repeatability/domain caveats remain unresolved.

No dedicated complete consecutive book replay has been generated for this instance. Some nearby events overlap the saved window centered on instance 375; the card itself contains context observations and horizon endpoints, not an invented continuous path.
